package excecoes;

import java.io.Serializable;

public class ExcecaoSenhaNaoConfere extends Exception implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public ExcecaoSenhaNaoConfere() {
	
	}
}