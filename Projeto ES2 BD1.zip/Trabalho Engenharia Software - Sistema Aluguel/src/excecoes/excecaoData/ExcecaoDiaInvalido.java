package excecoes.excecaoData;

import java.io.Serializable;

public class ExcecaoDiaInvalido extends ExcecaoDataInvalida implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public ExcecaoDiaInvalido() {
	
	}
}