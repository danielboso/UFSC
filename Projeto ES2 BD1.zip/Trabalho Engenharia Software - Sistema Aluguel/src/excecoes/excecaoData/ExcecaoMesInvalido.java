package excecoes.excecaoData;

import java.io.Serializable;

public class ExcecaoMesInvalido extends ExcecaoDataInvalida implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public ExcecaoMesInvalido() {
	
	}
}	