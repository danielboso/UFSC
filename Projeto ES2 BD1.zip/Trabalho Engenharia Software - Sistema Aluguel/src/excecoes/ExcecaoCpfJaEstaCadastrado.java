package excecoes;

import java.io.Serializable;

public class ExcecaoCpfJaEstaCadastrado extends ExcecaoCadastroCliente implements Serializable {

	private static final long serialVersionUID = 1L;

	public ExcecaoCpfJaEstaCadastrado() {

	}
}