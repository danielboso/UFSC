package visao;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class PainelTransparente extends JPanel {
	
	private static final long serialVersionUID = 1L;

	public PainelTransparente(Dimension sizePanel) {
		this.setOpaque(false);
		this.setLayout(null); // Antigo
		this.setSize(sizePanel);
		this.setLocation(0, 0);
		this.setBackground( new Color(0, 0, 0, 220));
		this.setVisible(true);
		this.repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
        g.setColor( getBackground() );
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    } 
}
