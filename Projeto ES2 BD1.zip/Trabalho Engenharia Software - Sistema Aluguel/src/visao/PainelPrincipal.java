package visao;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class PainelPrincipal extends JPanel {

	private static final long serialVersionUID = 1L;
	private ImageIcon imagemFundo;
	
	public PainelPrincipal(Dimension sizePanel) {
		this.setLayout(new GridBagLayout());
		this.setLayout(null);
		this.setSize(sizePanel);
		this.setLocation(0, 0);
		imagemFundo = new ImageIcon(getClass().getResource("/imagens/fundo.jpg"));
		this.setVisible(true);
		this.repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g.create();
		g2d.drawImage(imagemFundo.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
		g2d.dispose();
	}
}
