package visao;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JPanel;

import visao.ouvidoresDeAcoes.BotaoBuscarAcomodacoes;
import visao.ouvidoresDeAcoes.BotaoCadastroPropriedade;
import visao.ouvidoresDeAcoes.BotaoVerPropriedades;

public class PainelBotoesContaUsuario extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	JanelaPrincipal janelaPrincipal;
	
	public PainelBotoesContaUsuario(JanelaPrincipal janelaPrincipal, Dimension dimension) {
		this.janelaPrincipal = janelaPrincipal;
		setLayout(null);
		setSize(230, 230);
		setLocation((int) dimension.getWidth() / 2 - getWidth() / 2,
				(int) dimension.getHeight() / 2 - getHeight() / 2);
		this.setBackground( new Color(0, 0, 0, 0));
		inicializarPainel();
		this.setVisible(true);
		repaint();
	}
	
	private void inicializarPainel() {
		criaBotaoBuscarAcomodacoes();
		criaBotaoCadastrarPropriedade();
		criaBotaoVerPropriedades();
		criaBotaoVerReservas();
	}
	
	private void criaBotaoBuscarAcomodacoes() {
		JButton buscarAcomodacoes = new JButton("Buscar Acomoda��es");
		buscarAcomodacoes.setSize(165, 30);
		buscarAcomodacoes.setLocation(this.getWidth()/2 - (buscarAcomodacoes.getWidth()/2), 20);
		buscarAcomodacoes.setBackground(Color.WHITE);
		buscarAcomodacoes.setVisible(true);
		this.add(buscarAcomodacoes);
		buscarAcomodacoes.addActionListener(new BotaoBuscarAcomodacoes(janelaPrincipal));
	}
	
	private void criaBotaoCadastrarPropriedade() {
		JButton botaoCadastrarPropriedade = new JButton("Cadastrar propriedade");
		botaoCadastrarPropriedade.setSize(165, 30);
		botaoCadastrarPropriedade.setLocation(this.getWidth()/2 - (botaoCadastrarPropriedade.getWidth()/2), 60);
		botaoCadastrarPropriedade.setBackground(Color.WHITE);
		this.add(botaoCadastrarPropriedade);
		botaoCadastrarPropriedade.addActionListener(new BotaoCadastroPropriedade(janelaPrincipal));
	}
	
	private void criaBotaoVerPropriedades() {
		JButton botaoVerPropriedades = new JButton("Ver propriedades");
		botaoVerPropriedades.setSize(165, 30);
		botaoVerPropriedades.setLocation(this.getWidth()/2 - (botaoVerPropriedades.getWidth()/2), 100);
		botaoVerPropriedades.setBackground(Color.WHITE);
		this.add(botaoVerPropriedades);
		botaoVerPropriedades.addActionListener(new BotaoVerPropriedades(janelaPrincipal));
	}
	
	@SuppressWarnings("m�todo n�o terminado. Falta implementa��o BotaoVerReservasPropriedades")
	private void criaBotaoVerReservas() {
		JButton botaoVerReservas = new JButton("Ver reservas");
		botaoVerReservas.setSize(165, 30);
		botaoVerReservas.setLocation(this.getWidth()/2 - (botaoVerReservas.getWidth()/2), 140);
		botaoVerReservas.setBackground(Color.WHITE);
		this.add(botaoVerReservas);
		//botaoVerReservas.addActionListener(new BotaoVerReservasPropriedades());
	}
}
