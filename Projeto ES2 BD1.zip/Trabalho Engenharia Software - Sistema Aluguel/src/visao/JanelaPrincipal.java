package visao;

import java.awt.BorderLayout;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;

import javax.swing.JFrame;

import modelo.Fachada;
import modelo.usuario.Cliente;
import visao.paineisCadastro.PainelContaUsuario;
import visao.paineisCadastro.cliente.PainelCadastroCliente;
import visao.paineisLogin.PainelLoginUsuario;

public class JanelaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;

	private Fachada principal;

	public Fachada getPrincipal() {
		return principal;
	}

	private PainelLoginCadastro painelLoginCadastro;
	private PainelPrincipal painelPrincipal;
	private PainelTransparente painelTransparente;
	private PainelCadastroCliente painelCadastroCliente;
	private PainelLoginUsuario painelLoginUsuario;
	private PainelContaUsuario painelContaUsuario;

	public JanelaPrincipal() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null); // Antigo
		setSize(larguraTela(), alturaTela()); // Antigo
		setExtendedState(MAXIMIZED_BOTH);
		setTitle("Trabalho Engenharia de Software I - Sistema de Aluguel Para Temporada");
		iniciarPrograma();
		setVisible(true);
		repaint();
	}

	public PainelLoginCadastro getPainelLoginCadastro() {
		return painelLoginCadastro;
	}

	public PainelPrincipal getPainelPrincipal() {
		return painelPrincipal;
	}

	public PainelTransparente getPainelTransparente() {
		return painelTransparente;
	}

	public PainelCadastroCliente getPainelCadastroCliente() {
		return painelCadastroCliente;
	}

	public PainelLoginUsuario getPainelLoginUsuario() {
		return painelLoginUsuario;
	}
	
	public PainelContaUsuario getPainelContaUsuario() {
		return painelContaUsuario;
	}

	private void iniciarPrograma() {
		criaPainelPrincipal();
		criaPainelTransparente();
		criaPainelLoginCadastro();
	}
	
	
	private int larguraTela() {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Rectangle screenRect = ge.getMaximumWindowBounds();
		return screenRect.width;
	}

	private int alturaTela() {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Rectangle screenRect = ge.getMaximumWindowBounds();
		return screenRect.height;
	}
	

	private void criaPainelPrincipal() {
		painelPrincipal = new PainelPrincipal(this.getSize());		
		this.add(painelPrincipal);
	}

	private void criaPainelTransparente() {
		painelTransparente = new PainelTransparente(this.getSize());
		painelPrincipal.add(painelTransparente);
	}

	public void removerPaineis() {
		painelTransparente.removeAll();
		validate();
		repaint();
	}

	public void criaPainelLoginCadastro() {
		painelLoginCadastro = new PainelLoginCadastro(this);
		painelLoginCadastro.setLocation((this.getWidth() / 2) - (painelLoginCadastro.getWidth() / 2),
				(this.getHeight() / 2) - (painelLoginCadastro.getHeight() / 2));
		painelTransparente.add(painelLoginCadastro, BorderLayout.CENTER);
		this.revalidate();
		this.repaint();
	}

	public void criaPainelCadastroCliente() {
		painelCadastroCliente = new PainelCadastroCliente(painelTransparente.getSize(), this);
		painelTransparente.add(painelCadastroCliente);
	}

	public void criaPainelLoginUsuario() {
		painelLoginUsuario = new PainelLoginUsuario(painelTransparente.getSize(), this);
		painelTransparente.add(painelLoginUsuario);
	}
	
	public void criaPainelContaUsuario(Cliente cliente) {
		painelContaUsuario = new PainelContaUsuario(this, cliente);
		painelTransparente.add(painelContaUsuario);
	}
	
	public void logar(Cliente cliente) {
		criaPainelContaUsuario(cliente);
	}
}
