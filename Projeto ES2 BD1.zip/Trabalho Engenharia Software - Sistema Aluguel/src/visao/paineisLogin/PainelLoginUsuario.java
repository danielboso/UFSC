package visao.paineisLogin;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import excecoes.ExcecaoLoginUsuario;
import modelo.Fachada;
import visao.JanelaPrincipal;

public class PainelLoginUsuario extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldNomeUsuario;
	private JPasswordField passwordFieldSenha;
	private JanelaPrincipal janelaPrincipal;
	private String mensagemErro = "";
	
	public PainelLoginUsuario(Dimension sizePanel, JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		setBorder(BorderFactory.createTitledBorder(
				new LineBorder(Color.WHITE), "Login", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10),
				Color.WHITE));
		this.setBackground( new Color(0, 0, 0, 0));		
		setSize(250, 200);
		setLocation((int)(sizePanel.getWidth() / 2) - (getWidth() / 2), (int) (sizePanel.getHeight() / 2) - (getHeight() / 2));
		//this.setLayout(new GridLayout(1, 1)); // Novo
		setLayout(null); // Antigo
		adicionaComponentes();
		setVisible(true);
		repaint();
	}

	private void adicionaComponentes() {
		criaLabelId();
		criaTextFieldId();
		criaLabelSenha();
		criaTextFieldSenha();
		criaPainelBotoes();
	}
	
	private void criaLabelId() {
		JLabel labelId = new JLabel("Id:");
		labelId.setBounds(20, 35, 150, 20);
		labelId.setForeground(Color.WHITE);
		labelId.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelId);
	}

	private void criaTextFieldId() {
		textFieldNomeUsuario = new JTextField();
		textFieldNomeUsuario.setBounds(20, 55, 210, 20);
		textFieldNomeUsuario.setBorder(null);
		this.add(textFieldNomeUsuario);
	}
	
	private void criaLabelSenha(){
		JLabel labelSenha = new JLabel("Senha:");
		labelSenha.setBounds(20, 75, 50, 20);
		labelSenha.setForeground(Color.WHITE);
		labelSenha.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelSenha);
	}

	private void criaTextFieldSenha() {
		passwordFieldSenha = new JPasswordField();
		passwordFieldSenha.setBounds(20, 95, 210, 20);
		passwordFieldSenha.setBorder(null);
		this.add(passwordFieldSenha);
	}
	
	private void criaPainelBotoes() {
		PainelBotoesLogin painelBotoesLogin = new PainelBotoesLogin(janelaPrincipal);
		this.add(painelBotoesLogin);
		this.revalidate();
		repaint();
	}
	
	public void login() {
		try {
			String nomeUsuario = textFieldNomeUsuario.getText();
			String senhaUsuario = passwordFieldSenha.getText();
			if (Fachada.getInstance().verificaSeIdESenhaSaoCompativeis(nomeUsuario, senhaUsuario)) {
				janelaPrincipal.removerPaineis();
				janelaPrincipal.logar(Fachada.getInstance().retornaClientePeloId(nomeUsuario, senhaUsuario));
			} else {
				throw new ExcecaoLoginUsuario();
			}
		} catch (ExcecaoLoginUsuario e) {
			mensagemErro += "ID ou senha inv�lido!";
			JOptionPane.showMessageDialog(null, mensagemErro);
			janelaPrincipal.removerPaineis();
			janelaPrincipal.criaPainelLoginUsuario();
			janelaPrincipal.validate();
			janelaPrincipal.repaint();
		mensagemErro = "";
		}
	}
}
