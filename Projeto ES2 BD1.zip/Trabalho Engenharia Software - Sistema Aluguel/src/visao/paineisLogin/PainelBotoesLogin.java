package visao.paineisLogin;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

import visao.JanelaPrincipal;
import visao.ouvidoresDeAcoes.BotaoCancelarLoginCliente;
import visao.ouvidoresDeAcoes.BotaoEntrarLoginCliente;

public class PainelBotoesLogin extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	JanelaPrincipal janelaPrincipal;

	public PainelBotoesLogin(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		setLayout(new FlowLayout());
		setLocation(0, 125);
		setSize(250, 65);
		this.setBackground( new Color(0, 0, 0, 0));
		adicionaComponentes();
		this.setVisible(true);
		repaint();
	}
	
	private void adicionaComponentes() {
		criaBotaoEntrar();
		criaBotaoCancelar();
	}
	
	private void criaBotaoEntrar() {
		JButton botaoEntrar = new JButton("Entrar");
		botaoEntrar.setBackground(Color.WHITE);
		this.add(botaoEntrar);
		botaoEntrar.addActionListener(new BotaoEntrarLoginCliente(janelaPrincipal));
	}

	private void criaBotaoCancelar() {
		JButton botaoCancelar = new JButton("Cancelar");
		botaoCancelar.setBackground(Color.WHITE);
		this.add(botaoCancelar);
		botaoCancelar.addActionListener(new BotaoCancelarLoginCliente(janelaPrincipal));
	}
}
