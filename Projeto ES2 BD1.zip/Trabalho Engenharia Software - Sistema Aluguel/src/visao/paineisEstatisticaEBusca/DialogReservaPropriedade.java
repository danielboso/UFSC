package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.Font;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.text.MaskFormatter;

import visao.JanelaPrincipal;
import visao.ouvidoresDeAcoes.BotaoCancelarReserva;
import visao.ouvidoresDeAcoes.BotaoConfirmaReserva;

public class DialogReservaPropriedade extends JDialog {
	
	private static final long serialVersionUID = 1L;

	private JanelaPrincipal janelaPrincipal;
	
	private JFormattedTextField dataInicio;
	private JFormattedTextField dataFim;
	
	public DialogReservaPropriedade(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		this.setSize(195, 170);
		this.getContentPane().setBackground(Color.BLACK);
		this.setLocationRelativeTo(this);
		this.setLayout(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setResizable(false);
		this.setUndecorated(true);
		this.setVisible(true);
		criaComponentes();
	}
	
	public JFormattedTextField getDataInicio() {
		return dataInicio;
	}

	public JFormattedTextField getDataFim() {
		return dataFim;
	}

	private void criaComponentes() {
		criaLabelDataInicio();
		criaLabelDataFim();
		criaTextFieldDataInicio();
		criaTextFieldDataFim();
		criaBotaoConfirmar();
		criaBotaoCancelar();
	}
	
	private void criaLabelDataInicio() {
		JLabel labelDataInicio = new JLabel("In�cio:");
		labelDataInicio.setBounds(20, 20, 50, 15);
		labelDataInicio.setForeground(Color.WHITE);
		labelDataInicio.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelDataInicio);
	}
	
	private void criaLabelDataFim() {
		JLabel labelDataInicio = new JLabel("Fim:");
		labelDataInicio.setBounds(105, 20, 50, 15);
		labelDataInicio.setForeground(Color.WHITE);
		labelDataInicio.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelDataInicio);
	}
	
	private void criaTextFieldDataInicio() {
		try {
			MaskFormatter mascara = new MaskFormatter("##/##/####");
			mascara.setPlaceholderCharacter('_');
			dataInicio = new JFormattedTextField(mascara);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		dataInicio.setBounds(20, 40, 65, 20);
		dataInicio.setBorder(null);
		this.add(dataInicio);
	}
	
	private void criaTextFieldDataFim() {
		try {
			MaskFormatter mascara = new MaskFormatter("##/##/####");
			mascara.setPlaceholderCharacter('_');
			dataFim = new JFormattedTextField(mascara);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		dataFim.setBounds(105, 40, 65, 20);
		dataFim.setBorder(null);
		this.add(dataFim);
	}
	
	private void criaBotaoConfirmar() {
		JButton botaoConfirmar = new JButton("Confirmar");
		botaoConfirmar.setSize(100, 30);
		botaoConfirmar.setLocation(this.getWidth() / 2 - botaoConfirmar.getWidth() / 2, 70);
		botaoConfirmar.setBackground(Color.WHITE);
		this.add(botaoConfirmar);
		botaoConfirmar.addActionListener(new BotaoConfirmaReserva(janelaPrincipal));
	}
	
	private void criaBotaoCancelar() {
		JButton botaoCancelar = new JButton("Cancelar");
		botaoCancelar.setSize(100, 30);
		botaoCancelar.setLocation(this.getWidth() / 2 - botaoCancelar.getWidth() / 2, 110);
		botaoCancelar.setBackground(Color.WHITE);
		this.add(botaoCancelar);
		botaoCancelar.addActionListener(new BotaoCancelarReserva(janelaPrincipal, this));
	}

}
