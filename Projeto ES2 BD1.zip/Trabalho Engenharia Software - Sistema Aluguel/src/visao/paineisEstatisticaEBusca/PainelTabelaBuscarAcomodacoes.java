package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.Dimension;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

import modelo.propriedade.Propriedade;
import visao.tabela.CellRenderer;
import visao.tabela.TabelaBuscarAcomodacoes;

public class PainelTabelaBuscarAcomodacoes extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTable tabela;
	private TableModel modelo;
	
	public PainelTabelaBuscarAcomodacoes(List<Propriedade> propriedades, Dimension sizePanel) {
		setSize(800, 355);
		setLocation(0, 170);
		this.setBackground(new Color(0, 0, 0, 0));
		criaTabela(propriedades);
		this.setVisible(true);
		repaint();
	}

	private void criaTabela(List<Propriedade> propriedades) {
		tabela = new JTable();
		tabela.setLocation(0,0);
		tabela.setDefaultRenderer(Object.class, new CellRenderer());
		tabela.setPreferredScrollableViewportSize(new Dimension(
				this.getWidth()-20, this.getHeight()-100));
		modelo = new TabelaBuscarAcomodacoes(propriedades);
		tabela.setModel(modelo);
		tabela.setFillsViewportHeight(true);
		JScrollPane barraRolagemTabela = new JScrollPane(tabela);
		this.add(barraRolagemTabela);
	}
	
	public JTable getTabela() {
		return tabela;
	}
}
