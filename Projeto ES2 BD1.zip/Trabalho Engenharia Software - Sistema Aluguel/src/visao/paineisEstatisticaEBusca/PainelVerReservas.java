package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;

import modelo.Fachada;
import visao.JanelaPrincipal;
import visao.ouvidoresDeAcoes.BotaoVoltarVerPropriedades;
import visao.tabela.CellRenderer;
import visao.tabela.TabelaVerReservas;

public class PainelVerReservas extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private Integer idCliente;
	private JanelaPrincipal janelaPrincipal;

	public PainelVerReservas(JanelaPrincipal janelaPrincipal, Integer idCliente, Dimension sizePanel) {
		this.janelaPrincipal = janelaPrincipal;
		this.idCliente = idCliente;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Propriedades", Font.BOLD, Frame.NORMAL,
				new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setSize(800, 460);
		setLocation((int) sizePanel.getWidth() / 2 - getWidth() / 2, (int) sizePanel.getHeight() / 2 - getHeight() / 2);
		this.setBackground(new Color(0, 0, 0, 0));
		criaTabela();
		adicionaBotaoVoltar();
		this.setVisible(true);
		repaint();
	}

	private void adicionaBotaoVoltar() {
		JButton botaoVoltar = new JButton("Voltar");
		botaoVoltar.setBackground(Color.WHITE);
		this.add(botaoVoltar);
		botaoVoltar.addActionListener(new BotaoVoltarVerPropriedades(janelaPrincipal));
	}

	private void criaTabela() {
		JTable tabela = new JTable();
		tabela.setLocation(0,0);
		tabela.setDefaultRenderer(Object.class, new CellRenderer());
		tabela.setPreferredScrollableViewportSize(new Dimension(
				this.getWidth()-20, this.getHeight()-100));
		tabela.setFillsViewportHeight(true);
		tabela.setModel(new TabelaVerReservas(Fachada.getInstance().pegaReservasCliente(idCliente)));
		JScrollPane barraRolagemTabela = new JScrollPane(tabela);
		this.add(barraRolagemTabela);
		tabela.setEnabled(false);
		
	}

}
