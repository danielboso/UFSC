package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import modelo.InformacoesParaBusca;
import visao.JanelaPrincipal;

public class PainelVariaveisBuscaAcomodacao extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldPais;
	private JTextField textFieldEstado;
	private JTextField textFieldCidade;
	private JTextField textFieldBairro;
	private JTextField textFieldCep;
	private JTextField textFieldRua;
	
	private JanelaPrincipal janelaPrincipal;
	
	public PainelVariaveisBuscaAcomodacao(PainelBuscarAcomodacoes painelBuscarAcomodacoes, JanelaPrincipal janelaPrincipal, Dimension sizePanel) {
		this.janelaPrincipal = janelaPrincipal;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Buscar Acomoda��es", Font.BOLD, Frame.NORMAL,
				new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		this.setLayout(null);
		setSize(800, 460);
		setLocation((int) sizePanel.getWidth() / 2 - getWidth() / 2, (int) sizePanel.getHeight() / 2 - getHeight() / 2);
		this.setBackground(new Color(0, 0, 0, 0));
		adicionaComponentes(painelBuscarAcomodacoes);
		this.setVisible(true);
		repaint();
	}
	
	public JTextField getTextFieldPais() {
		return textFieldPais;
	}

	public JTextField getTextFieldEstado() {
		return textFieldEstado;
	}

	public JTextField getTextFieldCidade() {
		return textFieldCidade;
	}

	public JTextField getTextFieldBairro() {
		return textFieldBairro;
	}
	
	public JTextField getTextFieldCep() {
		return textFieldCep;
	}

	public JTextField getTextFieldRua() {
		return textFieldRua;
	}
	
	private void adicionaComponentes(PainelBuscarAcomodacoes painelBuscarAcomodacoes) {
		criaLabelPais();
		criaTextFieldPais();
		criaLabelEstado();
		criaTextFieldEstado();
		criaLabelCidade();
		criaTextFieldCidade();
		criaLabelBairro();
		criaTextFieldBairro();
		criaLabelCep();
		criaTextFieldCep();
		criaLabelRua();
		criaTextFieldRua();
		criaPainelBotoesBuscarAcomodacoes(painelBuscarAcomodacoes);
	}

	private void criaLabelPais() {
		JLabel labelPais = new JLabel("Pa�s:");
		labelPais.setBounds(20, 20, 50, 15);
		labelPais.setForeground(Color.WHITE);
		labelPais.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelPais);
	}
	
	private void criaTextFieldPais() {
		textFieldPais = new JTextField();
		textFieldPais.setBounds(20, 40, 210, 20);
		textFieldPais.setBorder(null);
		this.add(textFieldPais);
	}
	
	private void criaLabelEstado() {
		JLabel labelEstado = new JLabel("Estado:");
		labelEstado.setBounds(20, 60, 50, 15);
		labelEstado.setForeground(Color.WHITE);
		labelEstado.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelEstado);
	}
	
	private void criaTextFieldEstado() {
		textFieldEstado = new JTextField();
		textFieldEstado.setBounds(20, 80, 210, 20);
		textFieldEstado.setBorder(null);
		this.add(textFieldEstado);
	}
	
	private void criaLabelCidade() {
		JLabel labelCidade = new JLabel("Cidade:");
		labelCidade.setBounds(250, 20, 50, 15);
		labelCidade.setForeground(Color.WHITE);
		labelCidade.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCidade);
	}
	
	private void criaTextFieldCidade() {
		textFieldCidade = new JTextField();
		textFieldCidade.setBounds(250, 40, 210, 20);
		textFieldCidade.setBorder(null);
		this.add(textFieldCidade);
	}
	
	private void criaLabelBairro() {
		JLabel labelBairro = new JLabel("Bairro:");
		labelBairro.setBounds(250, 60, 50, 15);
		labelBairro.setForeground(Color.WHITE);
		labelBairro.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelBairro);
	}
	
	private void criaTextFieldBairro() {
		textFieldBairro = new JTextField();
		textFieldBairro.setBounds(250, 80, 210, 20);
		textFieldBairro.setBorder(null);
		this.add(textFieldBairro);
	}
	
	private void criaLabelCep() {
		JLabel labelCep = new JLabel("Cep:");
		labelCep.setBounds(490, 20, 50, 15);
		labelCep.setForeground(Color.WHITE);
		labelCep.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCep);
	}
	
	private void criaTextFieldCep() {
		textFieldCep = new JTextField();
		textFieldCep.setBounds(490, 40, 210, 20);
		textFieldCep.setBorder(null);
		this.add(textFieldCep);
	}
	
	private void criaLabelRua() {
		JLabel labelRua = new JLabel("Rua:");
		labelRua.setBounds(490, 60, 50, 15);
		labelRua.setForeground(Color.WHITE);
		labelRua.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelRua);
	}
	
	private void criaTextFieldRua() {
		textFieldRua = new JTextField();
		textFieldRua.setBounds(490, 80, 210, 20);
		textFieldRua.setBorder(null);
		this.add(textFieldRua);
	}
	
	private void criaPainelBotoesBuscarAcomodacoes(PainelBuscarAcomodacoes painelBuscarAcomodacoes) {
		PainelBotoesBuscarAcomodacoes painelBotoesBuscarAcomodacoes = new PainelBotoesBuscarAcomodacoes(painelBuscarAcomodacoes, janelaPrincipal);
		this.add(painelBotoesBuscarAcomodacoes);
	}
	
	public InformacoesParaBusca pegaInformacoesParaBusca() {
		String pais = textFieldPais.getText();
		String estado = textFieldEstado.getText();
		String cidade = textFieldCidade.getText();
		String cep = textFieldCep.getText();
		String bairro = textFieldBairro.getText();
		String rua = textFieldRua.getText();
		InformacoesParaBusca informacoesParaBusca = new InformacoesParaBusca(pais, estado, cidade, cep, bairro, rua);
		return informacoesParaBusca;
	}
}
