package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

import visao.JanelaPrincipal;
import visao.ouvidoresDeAcoes.BotaoCancelarPesquisaAcomodacoes;
import visao.ouvidoresDeAcoes.BotaoPesquisarAcomodacoes;
import visao.ouvidoresDeAcoes.BotaoReservarAcomodacao;

public class PainelBotoesBuscarAcomodacoes extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private JanelaPrincipal janelaPrincipal;
	
	public PainelBotoesBuscarAcomodacoes(PainelBuscarAcomodacoes painelBuscarAcomodacoes, JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		setLayout(new FlowLayout());
		setLocation(0, 120);
		setSize(800, 65);
		this.setBackground( new Color(0, 0, 0, 0));
		adicionaComponentes(painelBuscarAcomodacoes);
		this.setVisible(true);
		repaint();
	}

	private void adicionaComponentes(PainelBuscarAcomodacoes painelBuscarAcomodacoes) {
		criaBotaoPesquisar(painelBuscarAcomodacoes);
		criaBotaoCancelar();
		criaBotaoReservar();
	}

	private void criaBotaoPesquisar(PainelBuscarAcomodacoes painelBuscarAcomodacoes) {
		JButton botaoPesquisar = new JButton("Pesquisar");
		botaoPesquisar.setBackground(Color.WHITE);
		this.add(botaoPesquisar);
		botaoPesquisar.addActionListener(new BotaoPesquisarAcomodacoes(painelBuscarAcomodacoes, janelaPrincipal));
	}

	private void criaBotaoCancelar() {
		JButton botaoCancelar = new JButton("Cancelar");
		botaoCancelar.setBackground(Color.WHITE);
		this.add(botaoCancelar);
		botaoCancelar.addActionListener(new BotaoCancelarPesquisaAcomodacoes(janelaPrincipal));
	}
	
	private void criaBotaoReservar() {
		JButton botaoReservar = new JButton("Reservar");
		botaoReservar.setBackground(Color.WHITE);
		this.add(botaoReservar);
		botaoReservar.addActionListener(new BotaoReservarAcomodacao(janelaPrincipal));
	}

}
