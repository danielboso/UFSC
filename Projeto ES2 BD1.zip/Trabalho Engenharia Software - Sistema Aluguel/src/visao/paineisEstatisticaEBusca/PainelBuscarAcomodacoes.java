package visao.paineisEstatisticaEBusca;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import excecoes.excecaoData.ExcecaoAnoInvalido;
import excecoes.excecaoData.ExcecaoDiaInvalido;
import excecoes.excecaoData.ExcecaoMesInvalido;
import modelo.Fachada;
import modelo.atributos.Ano;
import modelo.atributos.Data;
import modelo.atributos.Dia;
import modelo.atributos.Mes;
import modelo.propriedade.Reserva;
import visao.JanelaPrincipal;

public class PainelBuscarAcomodacoes extends JPanel {

	private static final long serialVersionUID = 1L;

	private JanelaPrincipal janelaPrincipal;
	private PainelVariaveisBuscaAcomodacao painelVariaveisBuscaAcomodacao;
	private PainelTabelaBuscarAcomodacoes painelTabelaBuscarAcomodacoes;
	private DialogReservaPropriedade dialogReservaPropriedade;
	
	private boolean permitirReserva;
	private String mensagemErros = "";

	public PainelBuscarAcomodacoes(JanelaPrincipal janelaPrincipal, Dimension sizePanel) {
		this.janelaPrincipal = janelaPrincipal;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Buscar Acomoda��es", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		this.setLayout(null);
		setSize(800, 460);
		setLocation((int) sizePanel.getWidth() / 2 - getWidth() / 2, (int) sizePanel.getHeight() / 2 - getHeight() / 2);
		this.setBackground(new Color(0, 0, 0, 0));
		criaPainelVariaveisBusca();
		this.setVisible(true);
		repaint();
	}

	private void criaPainelVariaveisBusca() {
		painelVariaveisBuscaAcomodacao = new PainelVariaveisBuscaAcomodacao(this, janelaPrincipal, this.getSize());
		this.add(painelVariaveisBuscaAcomodacao);
	}

	public void criaPainelTabela() {
		painelTabelaBuscarAcomodacoes = new PainelTabelaBuscarAcomodacoes(
				Fachada.getInstance().buscarPropriedades(painelVariaveisBuscaAcomodacao.pegaInformacoesParaBusca()),
				this.getSize());
		this.add(painelTabelaBuscarAcomodacoes);
	}
	
	public void criaDialogReservarAcomodacao() {
		dialogReservaPropriedade = new DialogReservaPropriedade(janelaPrincipal);
	}

	public PainelVariaveisBuscaAcomodacao getPainelVariaveisBuscaAcomodacao() {
		return painelVariaveisBuscaAcomodacao;
	}

	public PainelTabelaBuscarAcomodacoes getPainelTabelaBuscarAcomodacoes() {
		return painelTabelaBuscarAcomodacoes;
	}
	
	public DialogReservaPropriedade getDialogReservaPropriedade() {
		return dialogReservaPropriedade;
	}
	
	private Data pegaDataInicio() {
		Dia diaInicio = pegaDiaInicio();
		Mes mesInicio = pegaMesInicio();
		Ano anoInicio = pegaAnoInicio();
		Data dataInicio = new Data(diaInicio, mesInicio, anoInicio);
		return dataInicio;
	}

	private Dia pegaDiaInicio() {
		Dia dia = null;
		try {
			dia = new Dia(dialogReservaPropriedade.getDataInicio().getText().substring(0, 2));
		} catch (ExcecaoDiaInvalido e) {
			this.mensagemErros += "Data: dia inv�lido (dia permitido est� no intervalo de [1, 31]\n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - Dia: insita uma dia v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return dia;
	}

	private Mes pegaMesInicio() {
		Mes mes = null;
		try {
			mes = new Mes(dialogReservaPropriedade.getDataInicio().getText().substring(3, 5));
		} catch (ExcecaoMesInvalido e) {
			this.mensagemErros += "Data: m�s inv�lido (m�s permitido est� no intervalo de [1, 12] \n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - m�s: insira uma m�s v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return mes;
	}

	private Ano pegaAnoInicio() {
		Ano ano = null;
		try {
			ano = new Ano(dialogReservaPropriedade.getDataInicio().getText().substring(6, 10));
		} catch (ExcecaoAnoInvalido e) {
			this.mensagemErros += "Data: ano inv�lido (ano permitido est� no intervalo de [0, 9999] \n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - ano: insita uma ano v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return ano;
	}
	
	private Data pegaDataFim() {
		Dia diaFim = pegaDiaFim();
		Mes mesFim = pegaMesFim();
		Ano anoFim = pegaAnoFim();
		Data dataFim = new Data(diaFim, mesFim, anoFim);
		return dataFim;
	}

	private Dia pegaDiaFim() {
		Dia dia = null;
		try {
			dia = new Dia(dialogReservaPropriedade.getDataFim().getText().substring(0, 2));
		} catch (ExcecaoDiaInvalido e) {
			this.mensagemErros += "Data: dia inv�lido (dia permitido est� no intervalo de [1, 31]\n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - Dia: insita uma dia v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return dia;
	}

	private Mes pegaMesFim() {
		Mes mes = null;
		try {
			mes = new Mes(dialogReservaPropriedade.getDataFim().getText().substring(3, 5));
		} catch (ExcecaoMesInvalido e) {
			this.mensagemErros += "Data: m�s inv�lido (m�s permitido est� no intervalo de [1, 12] \n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - m�s: insira uma m�s v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return mes;
	}

	private Ano pegaAnoFim() {
		Ano ano = null;
		try {
			ano = new Ano(dialogReservaPropriedade.getDataFim().getText().substring(6, 10));
		} catch (ExcecaoAnoInvalido e) {
			this.mensagemErros += "Data: ano inv�lido (ano permitido est� no intervalo de [0, 9999] \n";
			permitirReserva = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - ano: insita uma ano v�lido! \n";
			permitirReserva = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return ano;
	}
	
	public Reserva pegaDadosReserva(Integer idPropriedade) {
		Data dataInicio = pegaDataInicio();
		Data dataFim = pegaDataFim();
		Integer idCliente = Integer.parseInt(janelaPrincipal.getPainelContaUsuario().getClienteLogado().getCpf().toString());
		Reserva reserva = new Reserva(idPropriedade, idCliente, dataInicio, dataFim);
		return reserva;
	}
	
	public void fazReserva(Integer idPropriedade) {
		permitirReserva = true;
		Reserva reserva = pegaDadosReserva(idPropriedade);
		if (permitirReserva == true) {
			Fachada.getInstance().getClientes().get(reserva.getIdCliente()-1).getHospede().fazReserva(idPropriedade);
			Fachada.getInstance().cadastrarReserva(reserva);
			JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
		} else {
			JOptionPane.showMessageDialog(null, mensagemErros);
		}
		mensagemErros = "";
		
	}
}
