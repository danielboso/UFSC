package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoCancelarCadastroCliente implements ActionListener {
	
	private JanelaPrincipal janelaPrincipal;
	
	public BotaoCancelarCadastroCliente(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		janelaPrincipal.removerPaineis();
		janelaPrincipal.criaPainelLoginCadastro();
		janelaPrincipal.repaint();
	}
}
