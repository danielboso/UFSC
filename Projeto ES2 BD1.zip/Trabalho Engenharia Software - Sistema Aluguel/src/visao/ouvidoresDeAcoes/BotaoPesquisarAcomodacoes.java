package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;
import visao.paineisEstatisticaEBusca.PainelBuscarAcomodacoes;

public class BotaoPesquisarAcomodacoes implements ActionListener {

	PainelBuscarAcomodacoes painelBuscarAcomodacoes;
	JanelaPrincipal janelaPrincipal;

	public BotaoPesquisarAcomodacoes(PainelBuscarAcomodacoes painelBuscarAcomodacoes, JanelaPrincipal janelaPrincipal) {
		this.painelBuscarAcomodacoes = painelBuscarAcomodacoes;
		this.janelaPrincipal = janelaPrincipal;
	}

	public void actionPerformed(ActionEvent arg0) {
		if (painelBuscarAcomodacoes.getPainelTabelaBuscarAcomodacoes() != null) {
			painelBuscarAcomodacoes.getPainelTabelaBuscarAcomodacoes().removeAll();
			
		}
		painelBuscarAcomodacoes.criaPainelTabela();
		janelaPrincipal.revalidate();
		janelaPrincipal.repaint();
	}
}
