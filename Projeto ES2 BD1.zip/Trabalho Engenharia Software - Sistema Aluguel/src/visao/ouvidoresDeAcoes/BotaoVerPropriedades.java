package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoVerPropriedades implements ActionListener {

	private JanelaPrincipal janelaPrincipal;
	
	public BotaoVerPropriedades(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		janelaPrincipal.getPainelContaUsuario().getPainelBotoesContaUsuario().removeAll();
		janelaPrincipal.getPainelContaUsuario().criaPainelVerProriedades();
		janelaPrincipal.getPainelContaUsuario().revalidate();
		janelaPrincipal.repaint();
	}
}
