package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;
import visao.paineisEstatisticaEBusca.DialogReservaPropriedade;

public class BotaoCancelarReserva implements ActionListener {

	private JanelaPrincipal janelaPrincipal;
	private DialogReservaPropriedade dialogReservaPropriedade;
	
	public BotaoCancelarReserva(JanelaPrincipal janelaPrincipal, DialogReservaPropriedade dialogReservaPropriedade) {
		this.janelaPrincipal = janelaPrincipal;
		this.dialogReservaPropriedade = dialogReservaPropriedade;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		dialogReservaPropriedade.dispose();
		janelaPrincipal.getPainelContaUsuario().removeAll();
		janelaPrincipal.getPainelContaUsuario().criaPainelBotoesContaUsuario();
		janelaPrincipal.repaint();
	}	
}
