package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoVerReservasPropriedades implements ActionListener {
	
	JanelaPrincipal janelaPrincipal;
	
	public BotaoVerReservasPropriedades(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}	
}
