package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import visao.JanelaPrincipal;

public class BotaoReservarAcomodacao implements ActionListener {

	private JanelaPrincipal janelaPrincipal;
	
	public BotaoReservarAcomodacao(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Integer linhaSelecionada = janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes()
				.getPainelTabelaBuscarAcomodacoes().getTabela().getSelectedRow();
		if (linhaSelecionada != -1) {
			janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes().criaDialogReservarAcomodacao();
		} else {
			JOptionPane.showMessageDialog(null, "Voc� deve selecionar uma propriedade antes!");
		}
		
	}

}
