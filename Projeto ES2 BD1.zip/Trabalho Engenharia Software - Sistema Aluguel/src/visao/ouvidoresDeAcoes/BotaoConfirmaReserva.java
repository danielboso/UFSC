package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoConfirmaReserva implements ActionListener {

	private JanelaPrincipal janelaPrincipal;

	public BotaoConfirmaReserva(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Integer linhaSelecionada = janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes()
				.getPainelTabelaBuscarAcomodacoes().getTabela().getSelectedRow();
		Integer idPropriedade = (Integer) janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes()
				.getPainelTabelaBuscarAcomodacoes().getTabela().getModel().getValueAt(linhaSelecionada, 0);
		janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes().fazReserva(idPropriedade);
		janelaPrincipal.getPainelContaUsuario().getPainelBuscarAcomodacoes().getDialogReservaPropriedade().dispose();
		janelaPrincipal.getPainelContaUsuario().removeAll();
		janelaPrincipal.getPainelContaUsuario().criaPainelBotoesContaUsuario();
		janelaPrincipal.repaint();
	}
}
