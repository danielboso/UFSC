package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoLoginUsuario implements ActionListener {

	JanelaPrincipal janelaPrincipal;
	
	public BotaoLoginUsuario(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
		
	public void actionPerformed(ActionEvent arg0) {
		janelaPrincipal.removerPaineis();
		janelaPrincipal.criaPainelLoginUsuario();
		janelaPrincipal.validate();
		janelaPrincipal.repaint();
	}
}