package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoCancelarCadastroPropriedade implements ActionListener {
	
	private JanelaPrincipal janelaPrincipal;
	
	public BotaoCancelarCadastroPropriedade(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		janelaPrincipal.getPainelContaUsuario().removeAll();
		janelaPrincipal.getPainelContaUsuario().criaPainelBotoesContaUsuario();
		janelaPrincipal.repaint();
	}
}
