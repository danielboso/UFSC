package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoBuscarAcomodacoes implements ActionListener {
	
	private JanelaPrincipal janelaPrincipal;
	
	public BotaoBuscarAcomodacoes(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	public void actionPerformed(ActionEvent arg0) {
		janelaPrincipal.getPainelContaUsuario().getPainelBotoesContaUsuario().removeAll();
		janelaPrincipal.getPainelContaUsuario().criaPainelBuscarAcomodacoes();
		janelaPrincipal.getPainelContaUsuario().revalidate();
		janelaPrincipal.repaint();
	}
}
