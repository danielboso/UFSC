package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.paineisCadastro.propriedade.PainelCadastroPropriedade;

public class BotaoCadastrarPropriedade implements ActionListener {
	
	PainelCadastroPropriedade painelCadastroPropriedade;
	
	public BotaoCadastrarPropriedade(PainelCadastroPropriedade painelCadastroPropriedade) {
		this.painelCadastroPropriedade = painelCadastroPropriedade;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		painelCadastroPropriedade.cadastrarPropriedade();
	}
}
