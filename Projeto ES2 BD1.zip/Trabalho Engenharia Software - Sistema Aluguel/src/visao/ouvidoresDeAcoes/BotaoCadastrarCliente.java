package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.paineisCadastro.cliente.PainelCadastroCliente;

public class BotaoCadastrarCliente implements ActionListener {
	
	PainelCadastroCliente painelCadastroCliente;
	
	public BotaoCadastrarCliente(PainelCadastroCliente painelCadastroCliente) {
		this.painelCadastroCliente = painelCadastroCliente;
	}
	

	public void actionPerformed(ActionEvent arg0) {
		painelCadastroCliente.cadastrarCliente();
	}

}
