package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoCadastroUsuario implements ActionListener {

	private JanelaPrincipal janelaPrincipal;
	
	public BotaoCadastroUsuario(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		janelaPrincipal.removerPaineis();
		janelaPrincipal.criaPainelCadastroCliente();
		janelaPrincipal.validate();
		janelaPrincipal.repaint();
	}
}
