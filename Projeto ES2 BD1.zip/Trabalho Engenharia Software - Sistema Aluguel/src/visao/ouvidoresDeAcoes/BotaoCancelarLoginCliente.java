package visao.ouvidoresDeAcoes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import visao.JanelaPrincipal;

public class BotaoCancelarLoginCliente implements ActionListener {

	JanelaPrincipal janelaPrincipal;
	
	public BotaoCancelarLoginCliente(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
	}
	
	public void actionPerformed(ActionEvent arg0) {
		janelaPrincipal.removerPaineis();
		janelaPrincipal.criaPainelLoginCadastro();
	}
	
}
