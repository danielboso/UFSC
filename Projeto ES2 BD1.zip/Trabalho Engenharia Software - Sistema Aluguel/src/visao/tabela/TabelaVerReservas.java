package visao.tabela;

import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import modelo.propriedade.Reserva;

public class TabelaVerReservas extends AbstractTableModel {

	private final String[] nomeDasColunas = new String[] {};
	
	public TabelaVerReservas(List<Reserva> reservas) {
	
	}
	
	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

}
