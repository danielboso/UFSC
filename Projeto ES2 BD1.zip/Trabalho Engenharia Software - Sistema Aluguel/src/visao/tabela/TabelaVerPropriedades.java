package visao.tabela;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import modelo.propriedade.Propriedade;

public class TabelaVerPropriedades extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	private final String[] nomeDasColunas = new String[] { "Pais", "Estado", "Cidade", "Cep", "Bairro", "Rua", "N�mero",
			"Capacidade", "Pre�o Di�ria", "�rea" };
	private List<Propriedade> propriedades;

	public TabelaVerPropriedades(List<Propriedade> propriedades) {
		this.propriedades = propriedades;
	}

	@Override
	public int getColumnCount() {
		return nomeDasColunas.length;
	}

	@Override
	public int getRowCount() {
		return this.propriedades.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Propriedade propriedade = propriedades.get(rowIndex);
		switch (columnIndex) {
		// Pais
		case 0:
			return propriedade.getEndereco().getPais();
		// Estado
		case 1:
			return propriedade.getEndereco().getEstado();
		// Cidade
		case 2:
			return propriedade.getEndereco().getCidade();
		// Cep
		case 3:
			return propriedade.getEndereco().getCep();
		// Bairro
		case 4:
			return propriedade.getEndereco().getBairro();
		// Rua
		case 5:
			return propriedade.getEndereco().getRua();
		// N�mero
		case 6:
			return propriedade.getEndereco().getNumero();
		// Capacidade
		case 7:
			return propriedade.getCapacidade();
		// Pre�o Di�ria
		case 8:
			return propriedade.getPrecoDiaria();
		// �rea
		case 9:
			return propriedade.getArea();
		default:
			return null;
		}
	}

	@Override
	public String getColumnName(int column) {
		return nomeDasColunas[column];
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {
		case 0:
			return String.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		case 3:
			return String.class;
		case 4:
			return String.class;
		case 5:
			return String.class;
		case 6:
			return String.class;
		case 7:
			return Integer.class;
		case 8:
			return Integer.class;
		case 9:
			return Integer.class;
		default:
			return null;
		}
	}
}
