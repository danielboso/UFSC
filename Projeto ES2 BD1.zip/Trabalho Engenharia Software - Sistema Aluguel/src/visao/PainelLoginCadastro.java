package visao;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JButton;
import javax.swing.JPanel;

import visao.ouvidoresDeAcoes.BotaoCadastroUsuario;
import visao.ouvidoresDeAcoes.BotaoLoginUsuario;

public class PainelLoginCadastro extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JanelaPrincipal janelaPrincipal;
	
	public PainelLoginCadastro(JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		this.setPreferredSize(new Dimension(150, 95));
		this.setSize(150, 95);
		this.setBackground(new Color(0, 0, 0, 0));
		this.setLayout(null);
		this.setLocation(200, 200);
		this.inicializarPainel();
		this.setVisible(true);
		this.revalidate();
		this.repaint();
	}
	
	@Override
	public void paintComponent(Graphics g) {
        g.setColor( getBackground() );
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }
	
	private void inicializarPainel() {
		criaBotaoLogin();
		criaBotaoCadastrar();
	}
	
	private void criaBotaoLogin() {
		JButton botaoLogin = new JButton("Login");
		botaoLogin.setPreferredSize(new Dimension(120, 30));
		botaoLogin.setSize(120, 30);
		botaoLogin.setLocation(this.getWidth()/2 - (botaoLogin.getWidth()/2), 10);
		botaoLogin.setBackground(Color.WHITE);
		this.add(botaoLogin);
		botaoLogin.addActionListener(new BotaoLoginUsuario(janelaPrincipal));
	}
	
	private void criaBotaoCadastrar() {
		JButton botaoCadastrar = new JButton("Cadastre-se");
		botaoCadastrar.setPreferredSize(new Dimension(120, 30));
		botaoCadastrar.setSize(120, 30);
		botaoCadastrar.setLocation(this.getWidth()/2 - (botaoCadastrar.getWidth()/2), 50);
		botaoCadastrar.setBackground(Color.WHITE);	
		this.add(botaoCadastrar);
		botaoCadastrar.addActionListener(new BotaoCadastroUsuario(janelaPrincipal));
	}
}
