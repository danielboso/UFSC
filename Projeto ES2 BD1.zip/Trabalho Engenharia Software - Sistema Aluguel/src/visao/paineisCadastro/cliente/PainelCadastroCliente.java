package visao.paineisCadastro.cliente;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.util.Calendar;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import excecoes.ExcecaoCpfJaEstaCadastrado;
import excecoes.ExcecaoEntradaInvalida;
import excecoes.ExcecaoEntradaNaoPermitida;
import excecoes.ExcecaoIdJaEstaEmUso;
import excecoes.ExcecaoSenhaNaoConfere;
import excecoes.ExcecaoSexoInvalido;
import excecoes.excecaoData.ExcecaoAnoInvalido;
import excecoes.excecaoData.ExcecaoDiaInvalido;
import excecoes.excecaoData.ExcecaoMesInvalido;
import modelo.Comparador;
import modelo.Fachada;
import modelo.atributos.Ano;
import modelo.atributos.Cpf;
import modelo.atributos.Dia;
import modelo.atributos.Email;
import modelo.atributos.Mes;
import modelo.atributos.Nome;
import modelo.atributos.NomeUsuario;
import modelo.atributos.Senha;
import modelo.atributos.Sexo;
import modelo.atributos.Sobrenome;
import modelo.usuario.Cliente;
import visao.JanelaPrincipal;

public class PainelCadastroCliente extends JPanel {

	private static final long serialVersionUID = 1L;

	private PainelDadosDoCliente painelDadosDoCliente;
	private PainelDadosDeAcesso painelDadosDeAcesso;
	private PainelBotoesDeConfirmacao painelBotoesDeConfirmacao;

	private JanelaPrincipal janelaPrincipal;

	private Boolean permitirCadastro = true;
	private String mensagemErros = "";

	public PainelCadastroCliente(Dimension sizePanel, JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Cadastro de Cliente", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setLayout(null);
		this.setBackground(new Color(0, 0, 0, 0));
		setSize(280, 585);
		setLocation((int) sizePanel.getWidth() / 2 - getWidth() / 2, (int) sizePanel.getHeight() / 2 - getHeight() / 2);
		adicionaComponentes();
		setVisible(true);
		repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0, 0, getWidth(), getHeight());
		super.paintComponent(g);
	}

	private void adicionaComponentes() {
		criaPainelDadosDoCliente();
		criaPainelDadosDeAcesso();
		criaPainelBotoesDeConfirmacao();
	}

	private void criaPainelDadosDoCliente() {
		painelDadosDoCliente = new PainelDadosDoCliente();
		this.add(painelDadosDoCliente);
	}

	private void criaPainelDadosDeAcesso() {
		painelDadosDeAcesso = new PainelDadosDeAcesso();
		this.add(painelDadosDeAcesso);
	}

	private void criaPainelBotoesDeConfirmacao() {
		painelBotoesDeConfirmacao = new PainelBotoesDeConfirmacao(janelaPrincipal, this);
		this.add(painelBotoesDeConfirmacao);
	}

	// Dados cliente
	private Cpf pegaCpfCliente() {
		Cpf cpf = null;
		try {
			cpf = new Cpf(painelDadosDoCliente.getTextFieldCpf().getText());
			cpf.verificaExcecoes();
		} catch (ExcecaoEntradaInvalida | NumberFormatException | NullPointerException e) {
			this.mensagemErros += "Cpf: Insira um Cpf v�lido! \n";
			permitirCadastro = false;
		} catch (ExcecaoCpfJaEstaCadastrado e) {
			this.mensagemErros += "Cpf: cpf j� est� cadastrado! \n";
			permitirCadastro = false;
		} catch (ClassCastException e) {

		}
		return cpf;
	}

	private Nome pegaNomeCliente() {
		Nome nome = null;
		try {
			nome = new Nome(painelDadosDoCliente.getTextFieldNomeUsuario().getText());
			nome.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		} catch (ExcecaoEntradaNaoPermitida e) {
			this.mensagemErros += "Nome: N�o � permitido n�meros como nome! \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
		}
		return nome;
	}

	private Sobrenome pegaSobrenomeCliente() {
		Sobrenome sobrenome = null;
		try {
			sobrenome = new Sobrenome(painelDadosDoCliente.getTextFieldSobrenome().getText());
			sobrenome.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Sobrenome: Entrada inv�lida! \n";
			permitirCadastro = false;
		} catch (ExcecaoEntradaNaoPermitida e) {
			this.mensagemErros += "Sobrenome: N�o � permitido n�meros como sobrenome! \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
		}
		return sobrenome;
	}

	private Date pegaDataNascimentoCliente() {
		Dia diaNascimento = pegaDiaNascimento();
		Mes mesNascimento = pegaMesNascimento();
		Ano anoNascimento = pegaAnoNascimento();
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, Integer.parseInt(anoNascimento.toString()));
		calendar.set(Calendar.MONTH, Integer.parseInt(mesNascimento.toString()));
		calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(diaNascimento.toString()));
		Date dataNascimento = calendar.getTime();
		return dataNascimento;
	}

	private Dia pegaDiaNascimento() {
		Dia dia = null;
		try {
			dia = new Dia(painelDadosDoCliente.getDataNascimentoUsuario().getText().substring(0, 2));
		} catch (ExcecaoDiaInvalido e) {
			this.mensagemErros += "Data: dia inv�lido (dia permitido est� no intervalo de [1, 31]\n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - Dia: insita uma dia v�lido! \n";
			permitirCadastro = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return dia;
	}

	private Mes pegaMesNascimento() {
		Mes mes = null;
		try {
			mes = new Mes(painelDadosDoCliente.getDataNascimentoUsuario().getText().substring(3, 5));
		} catch (ExcecaoMesInvalido e) {
			this.mensagemErros += "Data: m�s inv�lido (m�s permitido est� no intervalo de [1, 12] \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - m�s: insira uma m�s v�lido! \n";
			permitirCadastro = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return mes;
	}

	private Ano pegaAnoNascimento() {
		Ano ano = null;
		try {
			ano = new Ano(painelDadosDoCliente.getDataNascimentoUsuario().getText().substring(6, 10));
		} catch (ExcecaoAnoInvalido e) {
			this.mensagemErros += "Data: ano inv�lido (ano permitido est� no intervalo de [0, 9999] \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
			this.mensagemErros += "Data - ano: insita uma ano v�lido! \n";
			permitirCadastro = false;
		} catch (StringIndexOutOfBoundsException e) {
		}
		return ano;
	}

	private Sexo pegaSexoCliente() {
		Sexo sexo = Sexo.NaoDefinido;

		try {
			if (painelDadosDoCliente.getBotaoSexoMasculino().isSelected() == true) {
				sexo = Sexo.Masculino;
			}
			if (painelDadosDoCliente.getBotaoSexoFeminino().isSelected() == true) {
				sexo = Sexo.Feminino;
			}
			if (sexo == Sexo.NaoDefinido) {
				throw new ExcecaoSexoInvalido();
			}
		} catch (ExcecaoSexoInvalido e) {
			this.mensagemErros += "Sexo: sexo inv�lido \n";
			permitirCadastro = false;
		}
		return sexo;
	}

	protected Email pegaEmailCliente() {
		Email email = null;
		try {
			email = new Email(painelDadosDoCliente.getTextFieldEmailUsuario().getText());
			email.verificaExcecoes();
		} catch (ExcecaoEntradaNaoPermitida e) {
			this.mensagemErros += "Email: email inv�lido! \n";
			permitirCadastro = false;
		} catch (ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Email: digite um email v�lido! \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
		}
		return email;
	}

	// Dados de Acesso
	protected NomeUsuario pegaNomeUsuario() {
		NomeUsuario nomeUsuario = null;
		try {
			nomeUsuario = new NomeUsuario(painelDadosDeAcesso.getTextFieldId().getText());
			nomeUsuario.verificaExcecoes();
		} catch (ExcecaoEntradaInvalida e) {
			this.mensagemErros += "iDCorreio: id inv�lido! \n";
			permitirCadastro = false;
		} catch (ExcecaoEntradaNaoPermitida e) {
			this.mensagemErros += "idCorreio: id n�o pode ser um n�mero! \n";
			permitirCadastro = false;
		} catch (ExcecaoIdJaEstaEmUso e) {
			this.mensagemErros += "idCorreio: id j� est� em uso! \n";
			permitirCadastro = false;
		} catch (NumberFormatException e) {
		}
		return nomeUsuario;
	}

	protected Senha pegaSenhaCliente() {
		Senha senha = null;
		Senha senhaRepetida = null;
		try {
			senha = new Senha(painelDadosDeAcesso.getPassawordFieldSenha().getText());
			senha.verificaExcecoes();
			senhaRepetida = new Senha(painelDadosDeAcesso.getPassawordFieldSenhaRepetida().getText());
			senhaRepetida.verificaExcecoes();
			if (Comparador.compararSenhasSaoIguais(senha, senhaRepetida) == true) {
				return senha;
			} else {
				throw new ExcecaoSenhaNaoConfere();
			}
		} catch (ExcecaoEntradaInvalida e) {
			mensagemErros += "Senha: Senha inv�lida \n";
			permitirCadastro = false;
		} catch (ExcecaoSenhaNaoConfere e) {
			this.mensagemErros += "Senha: senha n�o confere! \n";
			permitirCadastro = false;
		}
		return null;
	}

	private Cliente pegaDadosCliente() {
		Cpf cpf = pegaCpfCliente();
		Nome nome = pegaNomeCliente();
		Sobrenome sobrenome = pegaSobrenomeCliente();
		Date dataNascimento = pegaDataNascimentoCliente();
		Sexo sexo = pegaSexoCliente();
		Email email = pegaEmailCliente();
		NomeUsuario nomeUsuario = pegaNomeUsuario();
		Senha senha = pegaSenhaCliente();
		Fachada.getInstance();
		Cliente cliente = new Cliente(cpf, nome, sobrenome, dataNascimento, sexo, email,
				nomeUsuario, senha);
		return cliente;
	}

	public void cadastrarCliente() {
		permitirCadastro = true;
		Cliente cliente = pegaDadosCliente();
		if (permitirCadastro == true) {
			Fachada.getInstance().cadastrarCliente(cliente);
			janelaPrincipal.removerPaineis();
			JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
			janelaPrincipal.criaPainelLoginCadastro();
			janelaPrincipal.repaint();
		} else {
			JOptionPane.showMessageDialog(null, mensagemErros);
		}
		mensagemErros = "";
	}
}