package visao.paineisCadastro.cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class PainelEnderecoCliente extends JPanel {

	private static final long serialVersionUID = 1L;

	protected JTextField textIdentificacaoEndereco;
	protected JTextField textRua;
	protected JTextField textNumero;
	protected JTextField textComplemento;
	protected JTextField textCep;
	protected JTextField textBairro;
	protected JTextField textCidade;
	protected JTextField textEstado;
	protected JTextField textPais;
	
	public PainelEnderecoCliente() {
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE),
				"Endere�o", Font.BOLD, Frame.NORMAL, new Font("Lucida Grande",
						Font.PLAIN, 10), Color.WHITE));
		setLayout(null);
		setLocation(265, 20);
		setSize(480, 370);
		this.setBackground( new Color(0, 0, 0, 0));
		adicionaComponentes();
		setVisible(true);
	}
	
	@Override
	public void paintComponent(Graphics g) {
        g.setColor( getBackground() );
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }
	
	public JTextField getTextIdentificacaoEndereco() {
		return textIdentificacaoEndereco;
	}
	
	public JTextField getTextPais() {
		return textPais;
	}

	public JTextField getTextRua() {
		return textRua;
	}

	public JTextField getTextNumero() {
		return textNumero;
	}
	
	public JTextField getTextComplemento() {
		return textComplemento;
	}
	
	public JTextField getTextCep() {
		return textCep;
	}

	public JTextField getTextBairro() {
		return textBairro;
	}

	public JTextField getTextCidade() {
		return textCidade;
	}

	public JTextField getTextEstado() {
		return textEstado;
	}

	private void adicionaComponentes() {
		adicionaLabels();
		adicionaTextFields();
	}

	private void adicionaLabels() {
		criaLabelIdentificacaoEndereco();
		criaLabelPais();
		criaLabelCep();
		criaLabelRua();
		criaLabelNumero();
		criaLabelComplemento();
		criaLabelBairro();
		criaLabelCidade();
		criaLabelEstado();
	}

	private void adicionaTextFields() {
		criaTextFieldIdentificacaoEndereco();
		criaTextFieldPais();
		criaTextFieldRua();
		criaTextFieldNumero();
		criaTextFieldComplemento();
		criaTextFieldBairro();
		criaTextFieldCidade();
		criaTextFieldEstado();
		criaTextFieldCep();
	}

	private void criaLabelIdentificacaoEndereco() {
		JLabel labelIdenficacaoEndereco = new JLabel(
				"Identifica��o do endere�o:");
		labelIdenficacaoEndereco.setBounds(20, 20, 150, 20);
		labelIdenficacaoEndereco.setForeground(Color.WHITE);
		labelIdenficacaoEndereco.setFont(new Font("Lucida Grande", Font.BOLD,
				12));
		this.add(labelIdenficacaoEndereco);
	}
	
	private void criaTextFieldIdentificacaoEndereco() {
		textIdentificacaoEndereco = new JTextField();
		textIdentificacaoEndereco.setBounds(20, 40, 210, 20);
		textIdentificacaoEndereco.setBorder(null);
		this.add(textIdentificacaoEndereco);
	}
	
	private void criaLabelPais() {
		JLabel labelPais = new JLabel("Pa�s:");
		labelPais.setBounds(20, 60, 150, 20);
		labelPais.setForeground(Color.WHITE);
		labelPais.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelPais);
	}
	
	private void criaTextFieldPais() {
		textPais = new JTextField();
		textPais.setBounds(20, 80, 210, 20);
		textPais.setBorder(null);
		this.add(textPais);
	}
	
	private void criaLabelCep() {
		JLabel labelCep = new JLabel("CEP:");
		labelCep.setBounds(20, 100, 150, 20);
		labelCep.setForeground(Color.WHITE);
		labelCep.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCep);
	}
	
	private void criaTextFieldCep() {
		textCep = new JTextField();
		textCep.setBounds(20, 120, 210, 20);
		textCep.setBorder(null);
		this.add(textCep);
	}
	
	private void criaLabelRua() {
		JLabel labelEndereco = new JLabel("Rua:");
		labelEndereco.setBounds(20, 140, 150, 20);
		labelEndereco.setForeground(Color.WHITE);
		labelEndereco.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelEndereco);
	}
	
	private void criaTextFieldRua() {
		textRua = new JTextField();
		textRua.setBounds(20, 160, 210, 20);
		textRua.setBorder(null);
		this.add(textRua);
	}
	
	private void criaLabelNumero() {
		JLabel labelNumero = new JLabel("N�mero");
		labelNumero.setBounds(20, 180, 150, 20);
		labelNumero.setForeground(Color.WHITE);
		labelNumero.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelNumero);
	}
	
	private void criaTextFieldNumero() {
		textNumero = new JTextField();
		textNumero.setBounds(20, 200, 210, 20);
		textNumero.setBorder(null);
		this.add(textNumero);
	}
	
	private void criaLabelComplemento() {
		JLabel labelComplemento = new JLabel("Complemento:");
		labelComplemento.setBounds(250, 20, 150, 20);
		labelComplemento.setForeground(Color.WHITE);
		labelComplemento.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelComplemento);
	}
	
	private void criaTextFieldComplemento() {
		textComplemento = new JTextField();
		textComplemento.setBounds(250, 40, 210, 20);
		textComplemento.setBorder(null);
		this.add(textComplemento);
	}
	
	private void criaLabelBairro() {
		JLabel labelBairro = new JLabel("Bairro:");
		labelBairro.setBounds(250, 60, 150, 20);
		labelBairro.setForeground(Color.WHITE);
		labelBairro.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelBairro);
	}
	
	private void criaTextFieldBairro() {
		textBairro = new JTextField();
		textBairro.setBounds(250, 80, 210, 20);
		textBairro.setBorder(null);
		this.add(textBairro);
	}
	
	private void criaLabelCidade() {
		JLabel labelCidade = new JLabel("Cidade:");
		labelCidade.setBounds(250, 100, 150, 20);
		labelCidade.setForeground(Color.WHITE);
		labelCidade.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCidade);
	}
	
	private void criaTextFieldCidade() {
		textCidade = new JTextField();
		textCidade.setBounds(250, 120, 210, 20);
		textCidade.setBorder(null);
		this.add(textCidade);
	}

	private void criaLabelEstado() {
		JLabel labelEstado = new JLabel("Estado:");
		labelEstado.setBounds(250, 140, 150, 20);
		labelEstado.setForeground(Color.WHITE);
		labelEstado.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelEstado);
	}
	
	private void criaTextFieldEstado() {
		textEstado = new JTextField();
		textEstado.setBounds(250, 160, 210, 20);
		textEstado.setBorder(null);
		this.add(textEstado);
	}
}