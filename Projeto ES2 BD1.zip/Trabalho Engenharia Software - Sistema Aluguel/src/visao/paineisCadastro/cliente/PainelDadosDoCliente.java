package visao.paineisCadastro.cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class PainelDadosDoCliente extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldCpf;
	private JTextField textFieldNomeUsuario;
	private JTextField textFieldSobrenome;
	private JFormattedTextField dataNascimentoUsuario;
	private JRadioButton botaoSexoMasculino;
	private JRadioButton botaoSexoFeminino;
	private JTextField textFieldEmailUsuario;
	
	public PainelDadosDoCliente() {
		this.setBorder(BorderFactory.createTitledBorder(
				new LineBorder(Color.WHITE), "Dados do Cliente", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10),
				Color.WHITE));
		this.setBackground( new Color(0, 0, 0, 0));
		this.setLocation(15, 20);
		this.setSize(250, 275);
		this.setLayout(null);
		adicionaComponentes();
		this.setVisible(true);
		repaint();
	}
	
	public JTextField getTextFieldCpf() {
		return textFieldCpf;
	}
	
	public JTextField getTextFieldNomeUsuario() {
		return textFieldNomeUsuario;
	}

	public JTextField getTextFieldSobrenome() {
		return textFieldSobrenome;
	}

	public JFormattedTextField getDataNascimentoUsuario() {
		return dataNascimentoUsuario;
	}

	public JRadioButton getBotaoSexoMasculino() {
		return botaoSexoMasculino;
	}

	public JRadioButton getBotaoSexoFeminino() {
		return botaoSexoFeminino;
	}

	public JTextField getTextFieldEmailUsuario() {
		return textFieldEmailUsuario;
	}

	@Override
	public void paintComponent(Graphics g) {
        g.setColor( getBackground() );
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }
	
	private void adicionaComponentes() {
		criaLabelCpf();
		criaTextFieldCpf();
		criaLabelNome();
		criaTextFieldNome();
		criaLabelSobrenome();
		criaTextFieldSobrenome();
		criaLabelDataNascimento();
		criaTextFieldDataNascimento();
		criaLabelSexo();
		criaBotoesSexo();
		criaLabelEmail();
		criaTextFieldEmail();
	}
	
	public void criaLabelCpf() {
		JLabel labelCpf = new JLabel("Cpf:");
		labelCpf.setBounds(20, 20, 50, 15);
		labelCpf.setForeground(Color.WHITE);
		labelCpf.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCpf);
	}

	
	private void criaTextFieldCpf() {
		textFieldCpf = new JTextField();
		textFieldCpf.setBounds(20, 40, 210, 20);
		textFieldCpf.setBorder(null);
		this.add(textFieldCpf);
	}
	
	private void criaLabelNome() {
		JLabel labelNome = new JLabel("Nome:");
		labelNome.setBounds(20, 60, 50, 15);
		labelNome.setForeground(Color.WHITE);
		this.add(labelNome);
	}
	
	private void criaTextFieldNome() {
		textFieldNomeUsuario = new JTextField();
		textFieldNomeUsuario.setBounds(20, 80, 210, 20);
		textFieldNomeUsuario.setBorder(null);
		this.add(textFieldNomeUsuario);
	}
	
	private void criaLabelSobrenome() {
		JLabel sobrenome = new JLabel("Sobrenome");
		sobrenome.setBounds(20, 100, 100, 20);
		sobrenome.setForeground(Color.WHITE);
		this.add(sobrenome);
	}
	
	private void criaTextFieldSobrenome() {
		textFieldSobrenome = new JTextField();
		textFieldSobrenome.setBounds(20, 120, 210, 20);
		textFieldSobrenome.setBorder(null);
		this.add(textFieldSobrenome);
	}
	
	private void criaLabelDataNascimento() {
		JLabel dataNascimento = new JLabel("Data Nascimento:");
		dataNascimento.setBounds(20, 140, 100, 20);
		dataNascimento.setForeground(Color.WHITE);
		this.add(dataNascimento);
	}
	
	private void criaTextFieldDataNascimento() {
		dataNascimentoUsuario = new JFormattedTextField();
		dataNascimentoUsuario.setValue(new Date());
		dataNascimentoUsuario.setBounds(20, 160, 100, 20);
		dataNascimentoUsuario.setBorder(null);
		this.add(dataNascimentoUsuario);
	}
	
	private void criaLabelSexo() {
		JLabel labelSexo = new JLabel("Sexo:");
		labelSexo.setBounds(20, 180, 70, 20);
		labelSexo.setForeground(Color.WHITE);
		this.add(labelSexo);
	}
	
	private void criaBotoesSexo() {
		botaoSexoMasculino = new JRadioButton("Masculino");
		botaoSexoMasculino.setBackground(Color.BLACK);
		botaoSexoMasculino.setForeground(Color.WHITE);
		botaoSexoMasculino.setBorder(null);
		botaoSexoMasculino.setBounds(20, 200, 100, 20);
		botaoSexoMasculino.addActionListener(new BotaoSexoMasculino());
		this.add(botaoSexoMasculino);
		
		botaoSexoFeminino = new JRadioButton("Feminino");
		botaoSexoFeminino.setBackground(Color.BLACK);
		botaoSexoFeminino.setForeground(Color.WHITE);
		botaoSexoFeminino.setBorder(null);
		botaoSexoFeminino.setBounds(130, 200, 100, 20);
		botaoSexoFeminino.addActionListener(new BotaoSexoFeminino());
		this.add(botaoSexoFeminino);
	}
	
	private void criaLabelEmail() {
		JLabel labelEmail = new JLabel("E-mail:");
		labelEmail.setBounds(20, 220, 50, 20);
		labelEmail.setForeground(Color.WHITE);
		this.add(labelEmail);
	}
	
	private void criaTextFieldEmail() {
		textFieldEmailUsuario = new JTextField();
		textFieldEmailUsuario.setBounds(20, 240, 210, 20);
		textFieldEmailUsuario.setBorder(null);
		this.add(textFieldEmailUsuario);
	}
	
	private class BotaoSexoMasculino implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			botaoSexoMasculino.setSelected(true);
			botaoSexoFeminino.setSelected(false);
		}
	}

	private class BotaoSexoFeminino implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			botaoSexoFeminino.setSelected(true);
			botaoSexoMasculino.setSelected(false);
		}
	}
}
