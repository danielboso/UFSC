package visao.paineisCadastro.cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class PainelDadosDeAcesso extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldId;
	private JTextField passawordFieldSenha;
	private JTextField passawordFieldSenhaRepetida;	
	
	public PainelDadosDeAcesso() {
		setBorder(BorderFactory.createTitledBorder(
				new LineBorder(Color.WHITE), "Dados de Acesso", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10),
				Color.WHITE));
		this.setBackground( new Color(0, 0, 0, 0));
		setLocation(15, 300);
		setSize(250, 200);
		setLayout(null);
		adicionaComponentes();
		setVisible(true);
	}
	
	@Override
	public void paintComponent(Graphics g) {
        g.setColor( getBackground() );
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }
	
	public JTextField getTextFieldId() {
		return textFieldId;
	}

	public JTextField getPassawordFieldSenha() {
		return passawordFieldSenha;
	}

	public JTextField getPassawordFieldSenhaRepetida() {
		return passawordFieldSenhaRepetida;
	}
	
	private void adicionaComponentes() {
		criaLabelId();
		criaTextFieldId();
		criaLabelSenha();
		criaTextFieldSenha();
		criaLabelSenhaRepetida();
		criaTextFieldSenhaRepetida();
	}
	
	private void criaLabelId() {
		JLabel labelId = new JLabel("Id:");
		labelId.setBounds(20, 35, 150, 20);
		labelId.setForeground(Color.WHITE);
		labelId.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelId);
	}

	private void criaTextFieldId() {
		textFieldId = new JTextField();
		textFieldId.setBounds(20, 55, 210, 20);
		textFieldId.setBorder(null);
		this.add(textFieldId);
	}
	
	private void criaLabelSenha(){
		JLabel labelSenha = new JLabel("Senha:");
		labelSenha.setBounds(20, 75, 50, 20);
		labelSenha.setForeground(Color.WHITE);
		labelSenha.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelSenha);
	}

	private void criaTextFieldSenha() {
		passawordFieldSenha = new JPasswordField();
		passawordFieldSenha.setBounds(20, 95, 210, 20);
		passawordFieldSenha.setBorder(null);
		this.add(passawordFieldSenha);
	}
	
	private void criaLabelSenhaRepetida(){
		JLabel labelRedigitarSenha = new JLabel("Redigite a Senha:");
		labelRedigitarSenha.setBounds(20, 115, 100, 20);
		labelRedigitarSenha.setForeground(Color.WHITE);
		labelRedigitarSenha.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelRedigitarSenha);
	}

	private void criaTextFieldSenhaRepetida() {
		passawordFieldSenhaRepetida = new JPasswordField();
		passawordFieldSenhaRepetida.setBounds(20, 135, 210, 20);
		passawordFieldSenhaRepetida.setBorder(null);
		this.add(passawordFieldSenhaRepetida);
	}
}
