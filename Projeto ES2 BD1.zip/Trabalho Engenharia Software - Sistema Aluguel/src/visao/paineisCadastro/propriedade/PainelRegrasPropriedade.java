package visao.paineisCadastro.propriedade;

public class PainelRegrasPropriedade {

}
