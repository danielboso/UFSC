package visao.paineisCadastro.propriedade;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class PainelDescricaoPropriedade extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldArea;
	private JTextField textFieldCapacidade;
	private JTextField textFieldPrecoDiaria;
	private JTextField textFieldDescricao;
	
	public PainelDescricaoPropriedade() {
		this.setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Descri��o Propriedade", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setLayout(null);
		this.setBackground(new Color(0, 0, 0, 0));
		setSize(250, 200);
		setLocation(275, 15);
		adicionaComponentes();
		setVisible(true);
		repaint();
	}
	
	public JTextField getTextFieldArea() {
		return textFieldArea;
	}

	public JTextField getTextFieldCapacidade() {
		return textFieldCapacidade;
	}

	public JTextField getTextFieldPrecoDiaria() {
		return textFieldPrecoDiaria;
	}

	public JTextField getTextFieldDescricao() {
		return textFieldDescricao;
	}

	private void adicionaComponentes() {
		criaLabelArea();
		criaTextFieldArea();
		criaLabelCapacidade();
		criaTextFieldCapacidade();
		criaLabelPrecoDiaria();
		criaTextFieldPrecoDiaria();
		criaLabelDescricao();
		criaTextFieldDescricao();
	}
	
	private void criaLabelArea() {
		JLabel labelArea = new JLabel("�rea:");
		labelArea.setBounds(20, 20, 100, 15);
		labelArea.setForeground(Color.WHITE);
		labelArea.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelArea);
	}
	
	private void criaTextFieldArea() {
		textFieldArea = new JTextField();
		textFieldArea.setBounds(20, 40, 210, 20);
		textFieldArea.setBorder(null);
		this.add(textFieldArea);
	}
	
	private void criaLabelCapacidade() {
		JLabel labelCapacidade = new JLabel("Capacidade:");
		labelCapacidade.setBounds(20, 60, 100, 15);
		labelCapacidade.setForeground(Color.WHITE);
		labelCapacidade.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelCapacidade);
	}
	
	private void criaTextFieldCapacidade() {
		textFieldCapacidade = new JTextField();
		textFieldCapacidade.setBounds(20, 80, 210, 20);
		textFieldCapacidade.setBorder(null);
		this.add(textFieldCapacidade);
	}
	
	private void criaLabelPrecoDiaria() {
		JLabel labelPrecoDiaria = new JLabel("Preco Di�ria:");
		labelPrecoDiaria.setBounds(20, 100, 100, 15);
		labelPrecoDiaria.setForeground(Color.WHITE);
		labelPrecoDiaria.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelPrecoDiaria);
	}
	
	private void criaTextFieldPrecoDiaria() {
		textFieldPrecoDiaria = new JTextField();
		textFieldPrecoDiaria.setBounds(20, 120, 210, 20);
		textFieldPrecoDiaria.setBorder(null);
		this.add(textFieldPrecoDiaria);
	}
	
	private void criaLabelDescricao() {
		JLabel labelDescricao = new JLabel("Descricao:");
		labelDescricao.setBounds(20, 140, 140, 15);
		labelDescricao.setForeground(Color.WHITE);
		labelDescricao.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		this.add(labelDescricao);
	}
	
	private void criaTextFieldDescricao() {
		textFieldDescricao = new JTextField();
		textFieldDescricao.setBounds(20, 160, 210, 20);
		textFieldDescricao.setBorder(null);
		this.add(textFieldDescricao);
	}
}
