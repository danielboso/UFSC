package visao.paineisCadastro.propriedade;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import visao.JanelaPrincipal;
import visao.ouvidoresDeAcoes.BotaoCadastrarPropriedade;
import visao.ouvidoresDeAcoes.BotaoCancelarCadastroPropriedade;

public class PainelBotoesConfirmacaoPropriedade extends JPanel {

	private static final long serialVersionUID = 1L;

	private JButton botaoCadastrar;
	private JButton botaoCancelar;
	private JanelaPrincipal janelaPrincipal;
	private PainelCadastroPropriedade painelCadastroPropriedade;

	public PainelBotoesConfirmacaoPropriedade(JanelaPrincipal janelaPrincipal,
			PainelCadastroPropriedade painelCadastroPropriedade) {
		this.janelaPrincipal = janelaPrincipal;
		this.painelCadastroPropriedade = painelCadastroPropriedade;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Confirmacao", Font.BOLD, Frame.NORMAL,
				new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setLayout(new FlowLayout());
		setLocation(15, 380);
		setSize(250, 65);
		this.setBackground(new Color(0, 0, 0, 0));
		adicionaComponentes();
		this.setVisible(true);
		validate();
		repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0, 0, getWidth(), getHeight());
		super.paintComponent(g);
	}

	private void adicionaComponentes() {
		criaBotaoCadastrar();
		criaBotaoCancelar();
	}

	private void criaBotaoCadastrar() {
		botaoCadastrar = new JButton("Cadastrar");
		botaoCadastrar.setBackground(Color.WHITE);
		this.add(botaoCadastrar);
		botaoCadastrar.addActionListener(new BotaoCadastrarPropriedade(painelCadastroPropriedade));
	}

	private void criaBotaoCancelar() {
		botaoCancelar = new JButton("Cancelar");
		botaoCancelar.setBackground(Color.WHITE);
		this.add(botaoCancelar);
		botaoCancelar.addActionListener(new BotaoCancelarCadastroPropriedade(janelaPrincipal));
	}
}
