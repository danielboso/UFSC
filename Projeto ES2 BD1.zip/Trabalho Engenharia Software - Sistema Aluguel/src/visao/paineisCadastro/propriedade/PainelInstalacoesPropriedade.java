package visao.paineisCadastro.propriedade;

public class PainelInstalacoesPropriedade {

}
