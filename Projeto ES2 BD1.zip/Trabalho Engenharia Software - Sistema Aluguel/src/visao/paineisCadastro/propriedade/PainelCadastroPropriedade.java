package visao.paineisCadastro.propriedade;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import excecoes.ExcecaoEntradaInvalida;
import modelo.Endereco;
import modelo.Fachada;
import modelo.atributos.Bairro;
import modelo.atributos.Cep;
import modelo.atributos.Cidade;
import modelo.atributos.Complemento;
import modelo.atributos.Estado;
import modelo.atributos.Numero;
import modelo.atributos.Pais;
import modelo.atributos.Rua;
import modelo.propriedade.Propriedade;
import visao.JanelaPrincipal;

public class PainelCadastroPropriedade extends JPanel {

	private static final long serialVersionUID = 1L;

	JanelaPrincipal janelaPrincipal;
	PainelEnderecoPropriedade painelEnderecoPropriedade;
	PainelComodidadesPropriedade painelComodidadesPropriedade;
	PainelBotoesConfirmacaoPropriedade painelBotoesConfirmacaoPropriedade;
	PainelDescricaoPropriedade painelDescricaoPropriedade;
	
	String mensagemErros = "";
	Boolean permitirCadastro = true;

	public PainelCadastroPropriedade(Dimension sizePanel, JanelaPrincipal janelaPrincipal) {
		this.janelaPrincipal = janelaPrincipal;
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Cadastro de Propriedade", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setLayout(null);
		this.setBackground(new Color(0, 0, 0, 0));
		setSize(800, 460);
		setLocation((int) sizePanel.getWidth() / 2 - getWidth() / 2, (int) sizePanel.getHeight() / 2 - getHeight() / 2);
		adicionaComponentes();
		setVisible(true);
		repaint();
	}

	@SuppressWarnings("alguns m�todos desativados")
	private void adicionaComponentes() {
		criaPainelEnderecoPropriedade();
		//criaPainelComodidadesPropriedade();
		criaPainelConfirmacaoPropriedade();
		criaPainelDescricaoPropriedade();
	}

	private void criaPainelEnderecoPropriedade() {
		painelEnderecoPropriedade = new PainelEnderecoPropriedade();
		this.add(painelEnderecoPropriedade);
	}

	private void criaPainelComodidadesPropriedade() {
		painelComodidadesPropriedade = new PainelComodidadesPropriedade();
		this.add(painelComodidadesPropriedade);
	}

	private void criaPainelConfirmacaoPropriedade() {
		painelBotoesConfirmacaoPropriedade = new PainelBotoesConfirmacaoPropriedade(janelaPrincipal, this);
		this.add(painelBotoesConfirmacaoPropriedade);
	}
	
	private void criaPainelDescricaoPropriedade() {
		painelDescricaoPropriedade = new PainelDescricaoPropriedade();
		this.add(painelDescricaoPropriedade);
	}
	
	private Pais pegaPaisPropriedade() {
		Pais pais = null;
		try {
			pais = new Pais(painelEnderecoPropriedade.getTextFieldPais().getText());
			pais.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Pa�s: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return pais;
	}
	
	private Estado pegaEstadoPropriedade() {
		Estado estado = null;
		try {
			estado = new Estado(painelEnderecoPropriedade.getTextFieldEstado().getText());
			estado.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Estado: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return estado;
	}
	
	private Cidade pegaCidadePropriedade() {
		Cidade cidade = null;
		try {
			cidade = new Cidade(painelEnderecoPropriedade.getTextFieldCidade().getText());
			cidade.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return cidade;
	}
	
	private Bairro pegaBairroPropriedade() {
		Bairro bairro = null;
		try {
			bairro = new Bairro(painelEnderecoPropriedade.getTextFieldBairro().getText());
			bairro.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return bairro;
	}
	
	private Cep pegaCepPropriedade() {
		Cep cep = null;
		try {
			cep = new Cep(painelEnderecoPropriedade.getTextFieldCep().getText());
			cep.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida | NumberFormatException e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return cep;
	}
	
	private Rua pegaRuaPropriedade() {
		Rua rua = null;
		try {
			rua = new Rua(painelEnderecoPropriedade.getTextFieldRua().getText());
			rua.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return rua;
	}
	
	private Numero pegaNumeroPropriedade() {
		Numero numero = null;
		try {
			numero = new Numero(painelEnderecoPropriedade.getTextFieldNumero().getText());
			numero.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida | NumberFormatException e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return numero;
	}
	
	private Integer pegaAreaPropriedade() {
		Integer areaPropriedade = null;
		try {
			areaPropriedade = Integer.parseInt(painelDescricaoPropriedade.getTextFieldArea().getText());	
		}catch (NumberFormatException e) {
			this.mensagemErros += "�rea: Entrada Inv�lida!";
			permitirCadastro = false;
		}
		return areaPropriedade;
	}
	
	private Integer pegaCapacidadePropriedade() {
		Integer capacidadePropriedade = null;
		try {
			capacidadePropriedade = Integer.parseInt(painelDescricaoPropriedade.getTextFieldCapacidade().getText());
		} catch (NumberFormatException e) {
			this.mensagemErros += "Capacidade: Entrada Inv�lida!";
			permitirCadastro = false;
		}
		return capacidadePropriedade;
	}
	
	private Integer pegaPrecoDiariaPropriedade() {
		Integer precoDiariaPropriedade = null;
		try {
			precoDiariaPropriedade = Integer.parseInt(painelDescricaoPropriedade.getTextFieldPrecoDiaria().getText());
		} catch (NumberFormatException e) {
			this.mensagemErros += "Pre�o di�ria: Entrada Inv�lida!";
			permitirCadastro = false;
		}
		return precoDiariaPropriedade;
	}
	
	private String pegaDescricaoPropriedade() {
		String descricaoPropriedade = "";
		try {
			descricaoPropriedade = painelDescricaoPropriedade.getTextFieldCapacidade().getText();
			if(descricaoPropriedade.length() == 0) {
				throw new ExcecaoEntradaInvalida();
			}
		} catch (ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Descri��o: Entrada Inv�lida!";
			permitirCadastro = false;
		}
		return descricaoPropriedade;
	}
	
	private Complemento pegaComplementoPropriedade() {
		Complemento complemento = null;
		try {
			complemento = new Complemento(painelEnderecoPropriedade.getTextFieldComplemento().getText());
			complemento.verificaExcecoes();
		} catch (NullPointerException | ExcecaoEntradaInvalida e) {
			this.mensagemErros += "Nome: Entrada Inv�lida! \n";
			permitirCadastro = false;
		}
		return complemento;
	}
	
	private Endereco pegaEnderecoPropriedade() {
		Pais pais = pegaPaisPropriedade();
		Estado estado = pegaEstadoPropriedade();
		Cidade cidade = pegaCidadePropriedade();
		Cep cep = pegaCepPropriedade();
		Bairro bairro = pegaBairroPropriedade();
		Rua rua = pegaRuaPropriedade();
		Numero numero = pegaNumeroPropriedade();
		Complemento complemento = pegaComplementoPropriedade();
		Endereco endereco = new Endereco(pais, estado, cidade, cep, bairro, rua, numero, complemento);
		return endereco;
	}
	
	private Propriedade pegaDadosPropriedade() {
		Integer idPropriedade = Fachada.idPropriedade;
		Integer idProprietario = Integer.parseInt(janelaPrincipal.getPainelContaUsuario().getClienteLogado().getCpf().toString());
		String descricao = pegaDescricaoPropriedade();
		Integer capacidade = pegaCapacidadePropriedade();
		Integer precoDiaria = pegaPrecoDiariaPropriedade();
		Integer area = pegaAreaPropriedade();
		Endereco endereco = pegaEnderecoPropriedade();
		Propriedade propriedade = new Propriedade(idPropriedade, idProprietario, descricao, capacidade, precoDiaria, area, endereco);
		return propriedade;
	}
	
	public void cadastrarPropriedade() {
		permitirCadastro = true;
		Propriedade propriedade = pegaDadosPropriedade();
		if (permitirCadastro == true) {
			String mensagem = "";
			Fachada.getInstance().cadastrarPropriedade(propriedade);
			janelaPrincipal.getPainelContaUsuario().removeAll();
			JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
			mensagem += "ID Propriedade: " + propriedade.getIDPropriedade() + "\n";
			mensagem += "ID Propriet�rio: " + propriedade.getIDProprietario() + "\n";
			mensagem += "Descri��o: " + propriedade.getDescricao() + "\n";
			mensagem += "Capacidade: " + propriedade.getCapacidade() + "\n";
			mensagem += "Pre�o Di�ria: " + propriedade.getPrecoDiaria() + "\n";
			mensagem += "Area: " + propriedade.getArea() + "\n";
			mensagem += "\n";
			mensagem += "Endere�o:\n";
			mensagem += "Pa�s: " + propriedade.getEndereco().getPais() + "\n";
			mensagem += "Estado: " + propriedade.getEndereco().getEstado() + "\n";
			mensagem += "Cidade: " + propriedade.getEndereco().getCidade() + "\n";
			mensagem += "Cep: " + propriedade.getEndereco().getCep() + "\n";
			mensagem += "Bairro: " + propriedade.getEndereco().getBairro() + "\n";
			mensagem += "Rua: " + propriedade.getEndereco().getRua() + "\n";
			mensagem += "Numero: " + propriedade.getEndereco().getNumero() + "\n";
			mensagem += "Complemento: " + propriedade.getEndereco().getComplemento() + "\n";
			JOptionPane.showMessageDialog(null, mensagem);
			janelaPrincipal.getPainelContaUsuario().criaPainelBotoesContaUsuario();
			janelaPrincipal.repaint();
		} else {
			JOptionPane.showMessageDialog(null, mensagemErros);
		}
		mensagemErros = "";
	}
}
