package visao.paineisCadastro.propriedade;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class PainelComodidadesPropriedade extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JCheckBox cozinha;
	private JCheckBox internetSemFio;
	private JCheckBox tv;
	private JCheckBox aquecimentoCentral;
	private JCheckBox arCondicionado;
	private JCheckBox cabides;
	private JCheckBox cafeDaManha;
	private JCheckBox espacoUsoNotebook;
	private JCheckBox fornoEletrico;
	private JCheckBox ferroEletrico;
	private JCheckBox idealFamiliaCriancas;
	private JCheckBox interfone;
	private JCheckBox internet;
	private JCheckBox lareiraInterna;
	private JCheckBox maquinaLavar;
	private JCheckBox porteiro;
	private JCheckBox secadorCabelo;
	private JCheckBox secadora;
	private JCheckBox selfCheckIn;
	private JCheckBox tvCabo;
	private JCheckBox trancaPortaQuarto;
	private JCheckBox xampu;
	
	/*
	 -Cozinha
	 - Internet Sem Fio
	 - TV
	 - Aquecimento Central
	 - Ar-condicionado
	 - Cabides
	 - Caf� da Manh�
	 - Espa�o pronto para uso de notebook
	 - Ferro el�trico
	 - Ideal para fam�lias e crian�as
	 - Interfone
	 - Internet
	 - Lareira interna
	 - M�quina de Lavar
	 - Porteiro
	 - Secador de cabelo
	 - Secadora
	 - Self Check-In
	 - TV a Cabo
	 - Tranca na porta do quarto
	 - Xampu
	 */
	
	public PainelComodidadesPropriedade() {
		setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE), "Comodidades", Font.BOLD,
				Frame.NORMAL, new Font("Lucida Grande", Font.PLAIN, 10), Color.WHITE));
		setLayout(null);
		this.setBackground(new Color(0, 0, 0, 0));
		setSize(250, 450);
		setLocation(275, 15);
		adicionaComponentes();
		setVisible(true);
		repaint();
	} 
	
	private void adicionaComponentes() {
		adicionaCheckBoxCozinha();
		adicionaCheckBoxInternetSemFio();
		adicionaCheckBoxTv();
		adicionaCheckBoxAquecimentoCentral();
		adicionaCheckBoxArCondicionado();
		adicionaCheckBoxCabides();
		adicionaCheckBoxCafeDaManha();
		adicionaCheckBoxEspacoUsoNotebook();
		adicionaCheckBoxFornoEletrico();
		adicionaCheckBoxFerroEletrico();
		adicionaCheckBoxIdealFamiliaCriancas();
		adicionaCheckBoxInterfone();
		adicionaCheckBoxInternet();
		adicionaCheckBoxLareiraInterna();
		adicionaCheckBoxMaquinaLavar();
		adicionaCheckBoxPorteiro();
		adicionaCheckBoxSecadorCabelo();
		adicionaCheckBoxSecadora();
		adicionaCheckBoxSelfCheckIn();
		adicionaCheckBoxTvCabo();
		adicionaCheckBoxTrancaPortaQuarto();
	 	adicionaCheckBoxXampu();
	}
	
	private void adicionaCheckBoxCozinha() {
		cozinha = new JCheckBox("Cozinha");
		cozinha.setBounds(20, 20, 150, 20);
		cozinha.setBackground(Color.WHITE);
		cozinha.setForeground(Color.BLACK);
		this.add(cozinha);
	}
	
	private void adicionaCheckBoxInternetSemFio() {
		internetSemFio = new JCheckBox("Internet Sem Fio");
		internetSemFio.setBounds(20, 40, 150, 20);
		internetSemFio.setBackground(Color.WHITE);
		internetSemFio.setForeground(Color.BLACK);
		this.add(internetSemFio);
	}
	
	private void adicionaCheckBoxTv() {
		tv = new JCheckBox("TV");
		tv.setBounds(20, 60, 150, 20);
		tv.setBackground(Color.WHITE);
		tv.setForeground(Color.BLACK);
		this.add(tv);
	}
	
	private void adicionaCheckBoxAquecimentoCentral() {
		aquecimentoCentral = new JCheckBox("Aquecimento Central");
		aquecimentoCentral.setBounds(20, 80, 150, 20);
		aquecimentoCentral.setBackground(Color.WHITE);
		aquecimentoCentral.setForeground(Color.BLACK);
		this.add(aquecimentoCentral);
	}
	
	private void adicionaCheckBoxArCondicionado() {
		arCondicionado = new JCheckBox("Ar-Condicionado");
		arCondicionado.setBounds(20, 100, 150, 20);
		arCondicionado.setBackground(Color.WHITE);
		arCondicionado.setForeground(Color.BLACK);
		this.add(arCondicionado);
	}
	
	private void adicionaCheckBoxCabides() {
		cabides = new JCheckBox("Cabides");
		cabides.setBounds(20, 120, 150, 20);
		cabides.setBackground(Color.WHITE);
		cabides.setForeground(Color.BLACK);
		this.add(cabides);
	}
	
	private void adicionaCheckBoxCafeDaManha() {
		cafeDaManha = new JCheckBox("Caf� da Manh�");
		cafeDaManha.setBounds(20, 140, 150, 20);
		cafeDaManha.setBackground(Color.WHITE);
		cafeDaManha.setForeground(Color.BLACK);
		this.add(cafeDaManha);
	}
	
	private void adicionaCheckBoxEspacoUsoNotebook() {
		espacoUsoNotebook = new JCheckBox("Espa�o pronto para uso de notebook");
		espacoUsoNotebook.setBounds(20, 160, 150, 20);
		espacoUsoNotebook.setBackground(Color.WHITE);
		espacoUsoNotebook.setForeground(Color.BLACK);
		this.add(espacoUsoNotebook);
	}
	
	private void adicionaCheckBoxFornoEletrico() {
		fornoEletrico = new JCheckBox("Forno el�trico");
		fornoEletrico.setBounds(20, 180, 150, 20);
		fornoEletrico.setBackground(Color.WHITE);
		fornoEletrico.setForeground(Color.BLACK);
		this.add(fornoEletrico);
	}
	
	private void adicionaCheckBoxFerroEletrico() {
		ferroEletrico = new JCheckBox("Ferro el�trico");
		ferroEletrico.setBounds(20, 200, 150, 20);
		ferroEletrico.setBackground(Color.WHITE);
		ferroEletrico.setForeground(Color.BLACK);
		this.add(ferroEletrico);
	}
	
	private void adicionaCheckBoxIdealFamiliaCriancas() {
		idealFamiliaCriancas = new JCheckBox("Ideal para fam�lias e crian�as");
		idealFamiliaCriancas.setBounds(20, 220, 150, 20);
		idealFamiliaCriancas.setBackground(Color.WHITE);
		idealFamiliaCriancas.setForeground(Color.BLACK);
		this.add(idealFamiliaCriancas);
	}
	
	private void adicionaCheckBoxInterfone() {
		interfone = new JCheckBox("Interfone");
		interfone.setBounds(20, 240, 150, 20);
		interfone.setBackground(Color.WHITE);
		interfone.setForeground(Color.BLACK);
		this.add(interfone);
	}
	
	private void adicionaCheckBoxInternet() {
		internet = new JCheckBox("TV");
		internet.setBounds(20, 260, 150, 20);
		internet.setBackground(Color.WHITE);
		internet.setForeground(Color.BLACK);
		this.add(internet);
	}
	
	private void adicionaCheckBoxLareiraInterna() {
		lareiraInterna = new JCheckBox("Lareira interna");
		lareiraInterna.setBounds(20, 280, 150, 20);
		lareiraInterna.setBackground(Color.WHITE);
		lareiraInterna.setForeground(Color.BLACK);
		this.add(lareiraInterna);
	}
	
	private void adicionaCheckBoxMaquinaLavar() {
		maquinaLavar = new JCheckBox("M�quina de Lavar");
		maquinaLavar.setBounds(20, 300, 150, 20);
		maquinaLavar.setBackground(Color.WHITE);
		maquinaLavar.setForeground(Color.BLACK);
		this.add(maquinaLavar);
	}
	
	private void adicionaCheckBoxPorteiro() {
		porteiro = new JCheckBox("Porteiro");
		porteiro.setBounds(20, 320, 150, 20);
		porteiro.setBackground(Color.WHITE);
		porteiro.setForeground(Color.BLACK);
		this.add(porteiro);
	}
	
	private void adicionaCheckBoxSecadorCabelo() {
		secadorCabelo = new JCheckBox("Secador de cabelo");
		secadorCabelo.setBounds(20, 340, 150, 20);
		secadorCabelo.setBackground(Color.WHITE);
		secadorCabelo.setForeground(Color.BLACK);
		this.add(secadorCabelo);
	}
	
	private void adicionaCheckBoxSecadora() {
		secadora = new JCheckBox("Secadora");
		secadora.setBounds(20, 360, 150, 20);
		secadora.setBackground(Color.WHITE);
		secadora.setForeground(Color.BLACK);
		this.add(secadora);
	}
	
	private void adicionaCheckBoxSelfCheckIn() {
		selfCheckIn = new JCheckBox("Self Check-In");
		selfCheckIn.setBounds(20, 380, 150, 20);
		selfCheckIn.setBackground(Color.WHITE);
		selfCheckIn.setForeground(Color.BLACK);
		this.add(selfCheckIn);
	}
	
	private void adicionaCheckBoxTvCabo() {
		tvCabo = new JCheckBox("TV a Cabo");
		tvCabo.setBounds(20, 400, 150, 20);
		tvCabo.setBackground(Color.WHITE);
		tvCabo.setForeground(Color.BLACK);
		this.add(tvCabo);
	}
	
	private void adicionaCheckBoxTrancaPortaQuarto() {
		trancaPortaQuarto = new JCheckBox("Tranca na porta do quarto");
		trancaPortaQuarto.setBounds(20, 60, 150, 20);
		trancaPortaQuarto.setBackground(Color.WHITE);
		trancaPortaQuarto.setForeground(Color.BLACK);
		this.add(trancaPortaQuarto);
	}
	
	private void adicionaCheckBoxXampu() {
		xampu = new JCheckBox("Xampu");
		xampu.setBounds(20, 60, 150, 20);
		xampu.setBackground(Color.WHITE);
		xampu.setForeground(Color.BLACK);
		this.add(xampu);
	}
}
