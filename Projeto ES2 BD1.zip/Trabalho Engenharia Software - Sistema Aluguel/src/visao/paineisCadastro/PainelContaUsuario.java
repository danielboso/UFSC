package visao.paineisCadastro;

import java.awt.Color;

import javax.swing.JPanel;

import modelo.usuario.Cliente;
import visao.JanelaPrincipal;
import visao.PainelBotoesContaUsuario;
import visao.paineisCadastro.propriedade.PainelCadastroPropriedade;
import visao.paineisEstatisticaEBusca.PainelBuscarAcomodacoes;
import visao.paineisEstatisticaEBusca.PainelVerPropriedades;

public class PainelContaUsuario extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private Cliente cliente;
	private JanelaPrincipal janelaPrincipal;
	
	private PainelBotoesContaUsuario painelBotoesContaUsuario;
	private PainelCadastroPropriedade painelCadastroPropriedade;
	private PainelBuscarAcomodacoes painelBuscarAcomodacoes;
	
	public PainelContaUsuario(JanelaPrincipal janelaPrincipal, Cliente cliente) {
		this.cliente = cliente;
		this.janelaPrincipal = janelaPrincipal;
		setLayout(null);
		setSize(1350, 650);
		setLocation((int) janelaPrincipal.getPainelTransparente().getWidth() / 2 - getWidth() / 2,
				(int) janelaPrincipal.getPainelTransparente().getHeight() / 2 - getHeight() / 2);
		this.setBackground( new Color(0, 0, 0, 0));
		criaPainelBotoesContaUsuario();
		this.setVisible(true);
		repaint();
	}
	
	public Cliente getClienteLogado() {
		return cliente;
	}
	
	public PainelBotoesContaUsuario getPainelBotoesContaUsuario() {
		return painelBotoesContaUsuario;
	}

	public PainelCadastroPropriedade getPainelCadastroPropriedade() {
		return painelCadastroPropriedade;
	}
	
	public PainelBuscarAcomodacoes getPainelBuscarAcomodacoes() {
		return painelBuscarAcomodacoes;
	}

	public void criaPainelBotoesContaUsuario() {
		painelBotoesContaUsuario = new PainelBotoesContaUsuario(janelaPrincipal, this.getSize());
		this.add(painelBotoesContaUsuario);
	}
	
	public void criaPainelCadastroPropriedade() {
		painelCadastroPropriedade = new PainelCadastroPropriedade(this.getSize(), janelaPrincipal);
		this.add(painelCadastroPropriedade);
		repaint();
	}
	
	public void criaPainelVerProriedades() {
		PainelVerPropriedades painelVerPropriedades = new PainelVerPropriedades(janelaPrincipal, Integer.parseInt(cliente.getCpf().toString()), this.getSize());
		this.add(painelVerPropriedades);
	}
	
	public void criaPainelBuscarAcomodacoes() {
		painelBuscarAcomodacoes = new PainelBuscarAcomodacoes(janelaPrincipal, this.getSize());
		this.add(painelBuscarAcomodacoes);
	}
}
