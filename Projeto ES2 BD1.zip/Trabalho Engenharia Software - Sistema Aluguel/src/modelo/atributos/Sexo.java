package modelo.atributos;

public enum Sexo {	
	NaoDefinido, Masculino, Feminino;
}